package com.example.data.service

import android.content.Context
import android.os.Environment
import android.util.Log
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.net.URL
import kotlin.math.roundToInt

data class MediaMetadata(
    val title: String,
    val platform: String,
    val mimeType: String,
    val duration: String,
    val fileSize: Long,
    val downloadUrl: String,
    val isDemo: Boolean = false
)

object DownloaderService {
    private const val TAG = "DownloaderService"
    private val client = OkHttpClient()

    // Sample fallback assets that fit the Solo Leveling anime aesthetic
    private val ANIME_THEME_MUSIC_URL = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3"
    private val SHADOW_SOLDIER_VIDEO_URL = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4"

    fun extractMetadata(urlInput: String, isAudioOnly: Boolean): MediaMetadata {
        val url = urlInput.trim()
        val platform = when {
            url.contains("tiktok.com", ignoreCase = true) -> "TikTok"
            url.contains("youtube.com", ignoreCase = true) || url.contains("youtu.be", ignoreCase = true) -> "YouTube"
            url.contains("instagram.com", ignoreCase = true) -> "Instagram"
            url.contains("twitter.com", ignoreCase = true) || url.contains("x.com", ignoreCase = true) -> "Twitter / X"
            url.contains("facebook.com", ignoreCase = true) -> "Facebook"
            else -> "Web Hunter Link"
        }

        // Parse query parameters or name
        val parsedTitle = url.substringAfterLast("/").substringBefore("?").ifEmpty { "Shadow_Mana_Source" }
        val title = when (platform) {
            "YouTube" -> "Hunter Quest: Leveling Up Core " + (100..999).random()
            "TikTok" -> "Vibe Shadow Loop " + (10..99).random()
            "Instagram" -> "Monarch Reel Visual " + (10..99).random()
            else -> "Media_$parsedTitle"
        } + if (isAudioOnly) " (Audio)" else " (Video)"

        // Determine download Url
        val isDirectLink = url.endsWith(".mp3", ignoreCase = true) || 
                           url.endsWith(".mp4", ignoreCase = true) || 
                           url.endsWith(".m4a", ignoreCase = true) || 
                           url.endsWith(".wav", ignoreCase = true)

        val finalDownloadUrl = when {
            isDirectLink -> url
            isAudioOnly -> ANIME_THEME_MUSIC_URL
            else -> SHADOW_SOLDIER_VIDEO_URL
        }

        val duration = if (isAudioOnly) {
            "${(3..5).random()}:${(10..59).random()}"
        } else {
            "0:${(15..45).random()}"
        }

        val fileSize = if (isAudioOnly) {
            (3_000_000..7_000_000).random().toLong()
        } else {
            (12_000_000..25_000_000).random().toLong()
        }

        val mimeType = if (isAudioOnly) "audio/mpeg" else "video/mp4"

        return MediaMetadata(
            title = title,
            platform = platform,
            mimeType = mimeType,
            duration = duration,
            fileSize = fileSize,
            downloadUrl = finalDownloadUrl,
            isDemo = !isDirectLink
        )
    }

    suspend fun downloadMediaFile(
        context: Context,
        metadata: MediaMetadata,
        onProgress: (Int) -> Unit
    ): File? {
        return try {
            val request = Request.Builder()
                .url(metadata.downloadUrl)
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                Log.e(TAG, "Download failed with response code: ${response.code}")
                return null
            }

            val body = response.body
            if (body == null) {
                Log.e(TAG, "Response body is null")
                return null
            }

            // Create target file in the app's internal files folder under "shadow_media"
            val mediaDir = File(context.filesDir, "shadow_media")
            if (!mediaDir.exists()) {
                mediaDir.mkdirs()
            }

            val extension = if (metadata.mimeType.contains("audio")) "mp3" else "mp4"
            val sanitizedTitle = metadata.title.replace(Regex("[^a-zA-Z0-9_-]"), "_")
            val targetFile = File(mediaDir, "${sanitizedTitle}_${System.currentTimeMillis()}.$extension")

            val inputStream: InputStream = body.byteStream()
            val outputStream = FileOutputStream(targetFile)

            val buffer = ByteArray(4096)
            val totalBytes = body.contentLength()
            var bytesRead: Long = 0

            while (true) {
                val read = inputStream.read(buffer)
                if (read == -1) break
                outputStream.write(buffer, 0, read)
                bytesRead += read

                if (totalBytes > 0) {
                    val progress = ((bytesRead.toDouble() / totalBytes.toDouble()) * 100).roundToInt()
                    onProgress(progress.coerceIn(0, 100))
                }
            }

            outputStream.flush()
            outputStream.close()
            inputStream.close()

            Log.i(TAG, "File downloaded successfully at: ${targetFile.absolutePath}")
            targetFile
        } catch (e: Exception) {
            Log.e(TAG, "Error downloading media: ${e.message}", e)
            null
        }
    }
}
