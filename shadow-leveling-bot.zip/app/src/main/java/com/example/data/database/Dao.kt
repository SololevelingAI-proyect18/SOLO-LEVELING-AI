package com.example.data.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MediaDao {
    @Query("SELECT * FROM downloaded_media ORDER BY downloadedAt DESC")
    fun getAllMedia(): Flow<List<DownloadedMedia>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(media: DownloadedMedia): Long

    @Delete
    suspend fun delete(media: DownloadedMedia)
}

@Dao
interface ChatMessageDao {
    @Query("SELECT * FROM chat_messages ORDER BY timestamp DESC LIMIT 50")
    fun getRecentMessages(): Flow<List<ChatMessage>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(message: ChatMessage): Long

    @Query("DELETE FROM chat_messages")
    suspend fun clearAll()
}

@Dao
interface HunterStatsDao {
    @Query("SELECT * FROM hunter_stats WHERE id = 1")
    fun getStats(): Flow<HunterStats?>

    @Query("SELECT * FROM hunter_stats WHERE id = 1")
    suspend fun getStatsDirect(): HunterStats?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(stats: HunterStats)
}
