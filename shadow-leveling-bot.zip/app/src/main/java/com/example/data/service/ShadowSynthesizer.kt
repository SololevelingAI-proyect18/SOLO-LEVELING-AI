package com.example.data.service

import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs
import kotlin.math.sin

class ShadowSynthesizer {

    private var audioTrack: AudioTrack? = null
    private var isPlaying = false
    private var synthThread: Thread? = null
    private var currentTrackType = "synth_battle"

    private val _isPlayingState = MutableStateFlow(false)
    val isPlayingState: StateFlow<Boolean> = _isPlayingState.asStateFlow()

    private val _spectrumValues = MutableStateFlow(FloatArray(8) { 0.1f })
    val spectrumValues: StateFlow<FloatArray> = _spectrumValues.asStateFlow()

    fun play(trackType: String) {
        stop()
        currentTrackType = trackType
        isPlaying = true
        _isPlayingState.value = true
        synthThread = Thread {
            runSynthLoop()
        }.apply {
            name = "ShadowSynthThread"
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    fun stop() {
        isPlaying = false
        _isPlayingState.value = false
        synthThread?.interrupt()
        try {
            synthThread?.join(300)
        } catch (e: Exception) {
            // Ignore
        }
        synthThread = null
        try {
            audioTrack?.stop()
            audioTrack?.release()
        } catch (e: Exception) {
            // Ignore
        }
        audioTrack = null
        _spectrumValues.value = FloatArray(8) { 0.05f }
    }

    private fun runSynthLoop() {
        val sampleRate = 22050
        val bufferSize = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        try {
            audioTrack = AudioTrack(
                AudioManager.STREAM_MUSIC,
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize,
                AudioTrack.MODE_STREAM
            )
            audioTrack?.play()
        } catch (e: Exception) {
            _isPlayingState.value = false
            return
        }

        val shortBuffer = ShortArray(1024)
        var phase = 0.0

        // Frequencies in Hz for our Solo Leveling thematic chiptune loops
        val battleMelody = listOf(
            220f, 220f, 330f, 330f, 293f, 293f, 440f, 440f,
            392f, 392f, 330f, 330f, 293f, 349f, 220f, 220f
        )
        val ambientMelody = listOf(
            110f, 110f, 130f, 130f, 146f, 146f, 110f, 110f,
            165f, 165f, 196f, 196f, 146f, 146f, 110f, 110f
        )
        val marchMelody = listOf(
            146f, 146f, 146f, 196f, 220f, 220f, 220f, 196f,
            146f, 146f, 146f, 293f, 261f, 220f, 196f, 146f
        )

        val melody = when (currentTrackType) {
            "synth_ambient" -> ambientMelody
            "synth_march" -> marchMelody
            else -> battleMelody
        }

        var noteIndex = 0
        var samplesWrittenForNote = 0
        val samplesPerNote = sampleRate / 3 // ~333ms per note for an epic tempo

        val currentSpectrum = FloatArray(8) { 0.1f }

        while (isPlaying) {
            val freq = melody[noteIndex % melody.size]
            val omega = 2.0 * Math.PI * freq / sampleRate

            for (i in shortBuffer.indices) {
                phase += omega
                if (phase > 2.0 * Math.PI) {
                    phase -= 2.0 * Math.PI
                }

                val sample = when (currentTrackType) {
                    "synth_ambient" -> {
                        // Smooth sine wave with sub-harmonic and slight decay
                        val sine = sin(phase) + 0.4 * sin(phase * 0.5)
                        (sine * 7500.0).toInt().toShort()
                    }
                    "synth_march" -> {
                        // Heavy square/triangle hybrid for march
                        val square = if (phase < Math.PI) 1.0 else -1.0
                        val tri = 2.0 * abs(phase / Math.PI - 1.0) - 1.0
                        ((square * 0.35 + tri * 0.65) * 6500.0).toInt().toShort()
                    }
                    else -> {
                        // Energetic saw/triangle wave with noise transients (hi-hat simulation)
                        val saw = (phase / Math.PI) - 1.0
                        val noise = if (samplesWrittenForNote % 150 < 30) (Math.random() * 2.0 - 1.0) * 0.25 else 0.0
                        ((saw * 0.65 + noise) * 7500.0).toInt().toShort()
                    }
                }
                shortBuffer[i] = sample
                samplesWrittenForNote++

                if (samplesWrittenForNote >= samplesPerNote) {
                    samplesWrittenForNote = 0
                    noteIndex++
                }
            }

            try {
                audioTrack?.write(shortBuffer, 0, shortBuffer.size)
            } catch (e: Exception) {
                break
            }

            // Update spectrum analyzer with authentic dynamic simulation
            val baseIndex = (freq / 70f).toInt().coerceIn(0, 7)
            for (k in currentSpectrum.indices) {
                val target = if (k == baseIndex) 0.95f else if (abs(k - baseIndex) == 1) 0.55f else 0.15f
                currentSpectrum[k] = currentSpectrum[k] * 0.65f + target * 0.35f + (Math.random().toFloat() * 0.12f)
            }
            _spectrumValues.value = currentSpectrum.copyOf()
        }
    }
}
