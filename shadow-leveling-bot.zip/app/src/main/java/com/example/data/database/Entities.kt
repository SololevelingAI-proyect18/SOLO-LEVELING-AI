package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "downloaded_media")
data class DownloadedMedia(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val url: String,
    val filePath: String,
    val mimeType: String, // "audio/mpeg" or "video/mp4"
    val sourcePlatform: String, // "TikTok", "YouTube", "YouTube Music", "Instagram", "Twitter", "Facebook"
    val downloadedAt: Long = System.currentTimeMillis(),
    val fileSize: Long,
    val duration: String
)

@Entity(tableName = "chat_messages")
data class ChatMessage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sender: String,
    val message: String,
    val response: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String // "Pending", "Responding", "Success"
)

@Entity(tableName = "hunter_stats")
data class HunterStats(
    @PrimaryKey val id: Int = 1,
    val level: Int = 1,
    val exp: Int = 0,
    val requiredExp: Int = 100,
    val rank: String = "E-Rank", // E, D, C, B, A, S, National Level, Sovereign
    val shadowSoldiersCount: Int = 0,
    val botStatus: String = "DISCONNECTED", // DISCONNECTED, INITIALIZING, QR_SHOWN, CONNECTED
    val botName: String = "Igris (Shadow Bot)",
    val systemInstruction: String = "You are Igris, an elite Shadow Knight of Sung Jin-Woo. Respond with loyalty, reference the 'System' and hunter levels, keep text brief but martial in tone, and use Spanish. Ensure you are loyal to the Summoner.",
    val downloadCount: Int = 0
)
