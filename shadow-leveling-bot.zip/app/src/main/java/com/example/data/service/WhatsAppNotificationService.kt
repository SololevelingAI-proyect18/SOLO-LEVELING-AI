package com.example.data.service

import android.app.Notification
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.example.data.database.AppDatabase
import com.example.data.database.ChatMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class WhatsAppNotificationService : NotificationListenerService() {

    private val serviceScope = CoroutineScope(Dispatchers.IO)

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return

        val packageName = sbn.packageName
        // Listen only to WhatsApp and WhatsApp Business
        if (packageName != "com.whatsapp" && packageName != "com.whatsapp.w4b") {
            return
        }

        val notification = sbn.notification
        val extras = notification.extras ?: return

        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""

        if (title.isBlank() || text.isBlank()) return

        // Ignore common status updates, typing indicators, call notifications, etc.
        val lowerText = text.lowercase()
        val lowerTitle = title.lowercase()
        if (lowerText.contains("escribiendo...") || 
            lowerText.contains("typing...") || 
            lowerText.contains("llamada perdida") || 
            lowerText.contains("incoming call") ||
            lowerTitle.contains("whatsapp") ||
            lowerText.contains("nuevo mensaje")
        ) {
            return
        }

        val db = AppDatabase.getDatabase(applicationContext)
        val statsDao = db.hunterStatsDao()
        val chatMessageDao = db.chatMessageDao()

        serviceScope.launch {
            val stats = statsDao.getStatsDirect() ?: return@launch
            
            // Only respond if the bot is actually connected/enabled
            if (stats.botStatus != "CONNECTED") return@launch

            // Don't reply to our own messages if they somehow trigger a notification
            if (lowerTitle == "tú" || lowerTitle == "you" || title == stats.botName) {
                return@launch
            }

            // Find reply action and remote input
            var replyAction: Notification.Action? = null
            var remoteInput: RemoteInput? = null

            val actions = notification.actions
            if (actions != null) {
                for (action in actions) {
                    val inputs = action.remoteInputs ?: continue
                    for (input in inputs) {
                        if (input.resultKey != null) {
                            replyAction = action
                            remoteInput = input
                            break
                        }
                    }
                    if (replyAction != null) break
                }
            }

            if (replyAction != null && remoteInput != null) {
                Log.d("WhatsAppBotService", "Incoming message from $title: $text")

                // Add to database as Pending
                val logId = chatMessageDao.insert(
                    ChatMessage(
                        sender = title,
                        message = text,
                        response = "Canalizando respuesta del Sistema...",
                        status = "Pending"
                    )
                )

                // Generate response with Gemini
                val responseText = GeminiService.generateResponse(text, stats.systemInstruction)

                // Update database as Success
                chatMessageDao.insert(
                    ChatMessage(
                        id = logId,
                        sender = title,
                        message = text,
                        response = responseText,
                        status = "Success"
                    )
                )

                // Send reply
                val intent = Intent()
                val bundle = Bundle()
                bundle.putCharSequence(remoteInput.resultKey, responseText)
                RemoteInput.addResultsToIntent(arrayOf(remoteInput), intent, bundle)

                try {
                    replyAction.actionIntent.send(applicationContext, 0, intent)
                    Log.d("WhatsAppBotService", "Successfully replied to $title with: $responseText")
                    
                    // Increment experiences or stats!
                    val currentStats = statsDao.getStatsDirect()
                    if (currentStats != null) {
                        val newExp = currentStats.exp + 15
                        var level = currentStats.level
                        var required = currentStats.requiredExp
                        if (newExp >= required) {
                            level++
                            required = (required * 1.5).toInt()
                        }
                        statsDao.insertOrUpdate(
                            currentStats.copy(
                                exp = newExp % required,
                                requiredExp = required,
                                level = level
                            )
                        )
                    }
                } catch (e: Exception) {
                    Log.e("WhatsAppBotService", "Error executing reply intent", e)
                }
            }
        }
    }
}
