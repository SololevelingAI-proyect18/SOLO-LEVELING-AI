package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = SoloBlue,
    secondary = SoloPurple,
    tertiary = GoldAccent,
    background = AbyssBlack,
    surface = DarkSlateCard,
    onPrimary = AbyssBlack,
    onSecondary = SoloWhite,
    onBackground = SoloWhite,
    onSurface = SoloWhite,
    surfaceVariant = DarkSlateVariant,
    onSurfaceVariant = SoloWhite
  )

@Composable
fun MyApplicationTheme(
  // Force dark theme as default for the Solo Leveling System
  darkTheme: Boolean = true,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else DarkColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
