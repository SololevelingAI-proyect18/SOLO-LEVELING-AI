package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.database.ChatMessage
import com.example.data.database.DownloadedMedia
import com.example.data.database.HunterStats
import com.example.data.service.DownloaderService
import com.example.data.service.ShadowSynthesizer
import com.example.data.service.GeminiService
import com.example.data.service.MediaMetadata
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import kotlin.random.Random
import kotlin.math.roundToInt

class AppViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    private val mediaDao = db.mediaDao()
    private val chatMessageDao = db.chatMessageDao()
    private val hunterStatsDao = db.hunterStatsDao()

    val downloadedMedia: StateFlow<List<DownloadedMedia>> = mediaDao.getAllMedia()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val chatMessages: StateFlow<List<ChatMessage>> = chatMessageDao.getRecentMessages()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _hunterStats = MutableStateFlow(HunterStats())
    val hunterStats: StateFlow<HunterStats> = _hunterStats.asStateFlow()

    // Downloader States
    var urlInput by mutableStateOf("")
    var isAudioOnly by mutableStateOf(false)
    var extractionState by mutableStateOf("IDLE") // IDLE, EXTRACTING, ARISING, DOWNLOAD_PROGRESS, SUCCESS, ERROR
    var extractedMetadata by mutableStateOf<MediaMetadata?>(null)
    var downloadProgress by mutableStateOf(0)
    var errorMessage by mutableStateOf("")

    // WhatsApp QR States
    var botNameInput by mutableStateOf("Igris (Shadow Bot)")
    var systemInstructionInput by mutableStateOf("Eres Igris, caballero leal de Sung Jin-Woo. Responde con un tono marcial, breve, usa frases de 'Cazador' y acata órdenes del invocador.")
    var qrCodeUrl by mutableStateOf<String?>(null)
    var isInitializingBot by mutableStateOf(false)

    // Pairing Code (8 digits) States
    var connectionMode by mutableStateOf("QR") // "QR" or "PAIRING_CODE"
    var pairingPhoneNumber by mutableStateOf("")
    var pairingCode by mutableStateOf<String?>(null)
    var isGeneratingPairingCode by mutableStateOf(false)
    
    // Step-by-Step Simulated Connection States
    var isConnectingBot by mutableStateOf(false)
    var connectionStepText by mutableStateOf("")

    // Background chat mock server
    private var chatSimulationJob: Job? = null
    
    // Level Up Screen state variables
    var showLevelUpOverlay by mutableStateOf(false)
    var previousLevel by mutableStateOf(1)
    var textMessageInput by mutableStateOf("") // For manual testing of chatbot response

    // --- SHADOW PLAYER STATE & SYNTHESIS ---
    val shadowSynth = ShadowSynthesizer()
    var playingPreloadedTrack by mutableStateOf<PreloadedTrack?>(null)
    
    val preloadedTracks = listOf(
        PreloadedTrack("track1", "DESPERTAR DE SOMBRAS", "Sistema del Monarca", "02:15", "synth_ambient"),
        PreloadedTrack("track2", "¡ARRIBA, SOLDADOS!", "Monarca de las Sombras", "01:45", "synth_battle"),
        PreloadedTrack("track3", "MARCHA DE IGRIS", "Fuerza de Élite Sombra", "02:30", "synth_march")
    )

    fun playPreloadedTrack(track: PreloadedTrack) {
        playingPreloadedTrack = track
        shadowSynth.play(track.type)
    }

    fun stopPreloadedTrack() {
        playingPreloadedTrack = null
        shadowSynth.stop()
    }

    init {
        // Collect hunter stats from room database
        viewModelScope.launch {
            hunterStatsDao.getStats().collect { stats ->
                if (stats == null) {
                    val defaultStats = HunterStats()
                    hunterStatsDao.insertOrUpdate(defaultStats)
                    _hunterStats.value = defaultStats
                    botNameInput = defaultStats.botName
                    systemInstructionInput = defaultStats.systemInstruction
                } else {
                    _hunterStats.value = stats
                    botNameInput = stats.botName
                    systemInstructionInput = stats.systemInstruction
                    
                    // Restart simulation if database shows CONNECTED
                    if (stats.botStatus == "CONNECTED" && chatSimulationJob == null) {
                        startChatSimulation()
                    } else if ((stats.botStatus == "QR_SHOWN" || stats.botStatus == "INITIALIZING") && qrCodeUrl == null && pairingCode == null && !isInitializingBot && !isGeneratingPairingCode) {
                        // Safety fallback: if database status is intermediate but qrCodeUrl and pairingCode are null (due to app restart),
                        // reset status to DISCONNECTED so the user can regenerate the connection.
                        updateBotStatus("DISCONNECTED")
                    }
                }
            }
        }
    }

    fun setMode(mode: String) {
        if (connectionMode != mode) {
            connectionMode = mode
            // Reset to disconnected state if we were setting up, to avoid mixed QR/Code states
            val currentStatus = _hunterStats.value.botStatus
            if (currentStatus == "QR_SHOWN" || currentStatus == "INITIALIZING") {
                viewModelScope.launch {
                    qrCodeUrl = null
                    pairingCode = null
                    updateBotStatus("DISCONNECTED")
                }
            }
        }
    }

    fun startWhatsAppSetup() {
        viewModelScope.launch {
            isInitializingBot = true
            updateBotStatus("INITIALIZING")
            delay(1500) // Simular calibración dimensional
            
            val randomToken = List(16) { (('a'..'z') + ('A'..'Z') + ('0'..'9')).random() }.joinToString("")
            qrCodeUrl = "https://wa.me/connect_bot_$randomToken"
            
            isInitializingBot = false
            updateBotStatus("QR_SHOWN")
        }
    }

    fun startPairingCodeSetup() {
        if (pairingPhoneNumber.isBlank()) return
        viewModelScope.launch {
            isGeneratingPairingCode = true
            updateBotStatus("INITIALIZING")
            delay(1500) // Simular cálculo holográfico del anclaje
            
            // Generar código clásico de 8 caracteres de WhatsApp (ej: HD72-K9X2)
            val alphabet = "ABCDEFGHJKLMNOPQRSTUVWXYZ23456789" // Excluyendo O, I, 0, 1 para evitar confusión
            val part1 = List(4) { alphabet.random() }.joinToString("")
            val part2 = List(4) { alphabet.random() }.joinToString("")
            pairingCode = "$part1-$part2"
            
            isGeneratingPairingCode = false
            updateBotStatus("QR_SHOWN")
        }
    }

    fun simulateQRScan() {
        viewModelScope.launch {
            isConnectingBot = true
            val modeText = if (connectionMode == "QR") "CÓDIGO QR" else "CÓDIGO DE 8 DÍGITOS"
            val steps = listOf(
                "Enlazando mediante $modeText...",
                "Iniciando socket Baileys v6.7.14...",
                "Autenticando claves de cifrado con WhatsApp...",
                "Instalando directriz para '${_hunterStats.value.botName}'...",
                "Inyectando maná en canal de chat...",
                "¡Anclaje Sombra Establecido con Éxito!"
            )
            
            for (step in steps) {
                connectionStepText = step
                delay(1200)
            }
            
            updateBotStatus("CONNECTED")
            addExp(50) // Hunter Quest completed!
            recruitShadowSoldier()
            startChatSimulation()
            isConnectingBot = false
        }
    }

    fun disconnectWhatsApp() {
        viewModelScope.launch {
            chatSimulationJob?.cancel()
            chatSimulationJob = null
            qrCodeUrl = null
            pairingCode = null
            updateBotStatus("DISCONNECTED")
        }
    }

    fun updateBotConfig(name: String, instructions: String) {
        viewModelScope.launch {
            botNameInput = name
            systemInstructionInput = instructions
            val current = _hunterStats.value
            hunterStatsDao.insertOrUpdate(
                current.copy(
                    botName = name,
                    systemInstruction = instructions
                )
            )
            // Complete quest
            addExp(20)
        }
    }

    private fun startChatSimulation() {
        chatSimulationJob?.cancel()
        chatSimulationJob = viewModelScope.launch {
            // Wait for first message
            delay(5000)
            while (true) {
                // Periodically simulate incoming requests on WhatsApp
                simulateIncomingMessage()
                // Sleep between 15 to 25 seconds for next message
                delay(Random.nextLong(20000, 35000))
            }
        }
    }

    private suspend fun simulateIncomingMessage() {
        val senders = listOf(
            "+34 612 884 XXX (Cazador Jin)",
            "+54 9 11 5064 XXX (Yoo Jin-Ho)",
            "+52 1 55 4983 XXX (Cazadora Cha)",
            "+56 9 8455 XXX (Cazador Baek)",
            "+57 321 954 XXX (Asociación de Cazadores)"
        )
        val messages = listOf(
            "¡Hola! ¿Puedes descargar esta música? https://www.youtube.com/watch?v=sololeveling",
            "¿Me extraes este video de TikTok? https://tiktok.com/@shadow_monarch/video/739193",
            "Ayúdame a extraer este reel: https://instagram.com/reels/C8Xy-shadow",
            "Invocador, los niveles del calabozo están aumentando.",
            "¿Cuál es tu rango de cazador actual?",
            "¿Cuáles son tus órdenes para los soldados de sombra hoy?"
        )

        val sender = senders.random()
        val text = messages.random()

        val logId = chatMessageDao.insert(
            ChatMessage(
                sender = sender,
                message = text,
                response = "Invocando al Sistema...",
                status = "Pending"
            )
        )

        // Run Gemini to respond dynamically in the bot's tone
        val response = GeminiService.generateResponse(text, _hunterStats.value.systemInstruction)

        chatMessageDao.insert(
            ChatMessage(
                id = logId,
                sender = sender,
                message = text,
                response = response,
                status = "Success"
            )
        )

        // Gain some Hunter Mana EXP from active server interactions!
        addExp(15)

        // In case it's a downloading query, simulate automatic download injection
        if (text.contains("http")) {
            simulateAutoMediaExtraction(text)
        }
    }

    private fun simulateAutoMediaExtraction(url: String) {
        viewModelScope.launch {
            delay(3000) // Delay to perceive
            val meta = DownloaderService.extractMetadata(url, url.contains("música") || url.contains("song"))
            val mediaDir = File(getApplication<Application>().filesDir, "shadow_media")
            if (!mediaDir.exists()) mediaDir.mkdirs()
            
            // Simulating downloaded file
            val extension = if (meta.mimeType.contains("audio")) "mp3" else "mp4"
            val dummyFile = File(mediaDir, "${meta.title.replace(" ", "_")}_auto.$extension")
            if (!dummyFile.exists()) {
                dummyFile.createNewFile()
            }

            mediaDao.insert(
                DownloadedMedia(
                    title = meta.title,
                    url = url,
                    filePath = dummyFile.absolutePath,
                    mimeType = meta.mimeType,
                    sourcePlatform = meta.platform,
                    fileSize = meta.fileSize,
                    duration = meta.duration
                )
            )
            addExp(25)
            recruitShadowSoldier()
        }
    }

    // Manual Local Extract & Download Actions
    fun triggerMediaExtraction() {
        val url = urlInput.trim()
        if (url.isEmpty()) {
            errorMessage = "La URL del calabozo de contenido está vacía."
            extractionState = "ERROR"
            return
        }

        viewModelScope.launch {
            extractionState = "EXTRACTING"
            delay(1500) // Reading metadata...
            
            try {
                val metadata = DownloaderService.extractMetadata(url, isAudioOnly)
                extractedMetadata = metadata
                
                // Let the Solo Leveling "Arise" overlay play
                extractionState = "AR ARISING" // Special delay screen
                delay(2200) // Aesthetic surge pause

                extractionState = "DOWNLOAD_PROGRESS"
                downloadProgress = 0
                
                val downloadedFile = DownloaderService.downloadMediaFile(
                    getApplication(),
                    metadata
                ) { progress ->
                    downloadProgress = progress
                }

                if (downloadedFile != null) {
                    val mediaId = mediaDao.insert(
                        DownloadedMedia(
                            title = metadata.title,
                            url = url,
                            filePath = downloadedFile.absolutePath,
                            mimeType = metadata.mimeType,
                            sourcePlatform = metadata.platform,
                            fileSize = metadata.fileSize,
                            duration = metadata.duration
                        )
                    )
                    
                    extractionState = "SUCCESS"
                    urlInput = "" // Clear input
                    addExp(35) // Big EXP for core extraction!
                    recruitShadowSoldier()
                    
                    // Increment overall download count in statistics
                    val current = _hunterStats.value
                    hunterStatsDao.insertOrUpdate(current.copy(downloadCount = current.downloadCount + 1))
                } else {
                    errorMessage = "Fallo la extracción de sombra: No se pudo descargar el flujo binario."
                    extractionState = "ERROR"
                }
            } catch (e: Exception) {
                errorMessage = "Inestabilidad en la grieta dimensional: ${e.localizedMessage ?: e.message}"
                extractionState = "ERROR"
            }
        }
    }

    fun deleteMedia(media: DownloadedMedia) {
        viewModelScope.launch {
            try {
                val file = File(media.filePath)
                if (file.exists()) {
                    file.delete()
                }
            } catch (e: Exception) {
                Log.e("ViewModel", "Error deleting file: ${e.message}")
            }
            mediaDao.delete(media)
        }
    }

    // Chat logs actions
    fun clearChatLogs() {
        viewModelScope.launch {
            chatMessageDao.clearAll()
        }
    }

    fun sendManualTestMessage() {
        val msg = textMessageInput.trim()
        if (msg.isEmpty()) return
        textMessageInput = ""
        viewModelScope.launch {
            val logId = chatMessageDao.insert(
                ChatMessage(
                    sender = "Invocador (Tú)",
                    message = msg,
                    response = "Invocando respuesta...",
                    status = "Pending"
                )
            )
            val reply = GeminiService.generateResponse(msg, _hunterStats.value.systemInstruction)
            chatMessageDao.insert(
                ChatMessage(
                    id = logId,
                    sender = "Invocador (Tú)",
                    message = msg,
                    response = reply,
                    status = "Success"
                )
            )
            addExp(10)
        }
    }

    // Hunter leveling mechanism
    private suspend fun addExp(amount: Int) {
        val current = _hunterStats.value
        var newExp = current.exp + amount
        var newLevel = current.level
        var newReq = current.requiredExp

        while (newExp >= newReq) {
            newExp -= newReq
            newLevel++
            newReq = (newReq * 1.5).roundToInt()
        }

        val newRank = calculateRank(newLevel)

        if (newLevel > current.level) {
            previousLevel = current.level
            showLevelUpOverlay = true
        }

        hunterStatsDao.insertOrUpdate(
            current.copy(
                level = newLevel,
                exp = newExp,
                requiredExp = newReq,
                rank = newRank
            )
        )
    }

    private fun calculateRank(level: Int): String {
        return when {
            level < 5 -> "E-Rank Hunter"
            level < 10 -> "D-Rank Hunter"
            level < 18 -> "C-Rank Hunter"
            level < 28 -> "B-Rank Hunter"
            level < 40 -> "A-Rank Hunter"
            level < 60 -> "S-Rank Hunter"
            level < 90 -> "National Level Hunter"
            else -> "Shadow Sovereign (Monarch)"
        }
    }

    private suspend fun recruitShadowSoldier() {
        val current = _hunterStats.value
        hunterStatsDao.insertOrUpdate(
            current.copy(shadowSoldiersCount = current.shadowSoldiersCount + 1)
        )
    }

    private suspend fun updateBotStatus(status: String) {
        val current = _hunterStats.value
        hunterStatsDao.insertOrUpdate(
            current.copy(botStatus = status)
        )
    }

    fun isNotificationAccessGranted(context: Context): Boolean {
        val packageName = context.packageName
        val flat = android.provider.Settings.Secure.getString(
            context.contentResolver,
            "enabled_notification_listeners"
        )
        return flat != null && flat.contains(packageName)
    }

    fun openNotificationAccessSettings(context: Context) {
        val intent = android.content.Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")
        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    override fun onCleared() {
        super.onCleared()
        shadowSynth.stop()
    }
}

data class PreloadedTrack(
    val id: String,
    val title: String,
    val composer: String,
    val duration: String,
    val type: String
)
