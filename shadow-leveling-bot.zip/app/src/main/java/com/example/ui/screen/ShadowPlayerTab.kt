package com.example.ui.screen

import android.media.MediaPlayer
import android.net.Uri
import android.util.Log
import android.widget.VideoView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.R
import com.example.data.database.DownloadedMedia
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppViewModel
import com.example.ui.viewmodel.PreloadedTrack
import java.io.File

@Composable
fun ShadowPlayerTab(
    viewModel: AppViewModel,
    mediaList: List<DownloadedMedia>,
    playingMedia: DownloadedMedia?,
    isAudioPlaying: Boolean,
    onPlayMedia: (DownloadedMedia) -> Unit,
    onStopAudio: () -> Unit
) {
    val context = LocalContext.current
    val spectrumValuesState = viewModel.shadowSynth.spectrumValues.collectAsState()
    val isSynthPlaying by viewModel.shadowSynth.isPlayingState.collectAsState()

    // Character State
    var selectedChar by remember { mutableStateOf("jinwoo") } // "jinwoo", "igris", "beru", "iron"
    
    // Auto-dialogue State
    var currentDialogue by remember { mutableStateOf("¡El Sistema aprueba este ritmo!") }
    val isPlayingAny = isSynthPlaying || isAudioPlaying || (playingMedia != null && playingMedia.mimeType.contains("video"))

    // Periodic dialogue trigger when playing
    LaunchedEffect(isPlayingAny, selectedChar) {
        if (isPlayingAny) {
            val dialogues = when (selectedChar) {
                "jinwoo" -> listOf(
                    "¡El Sistema aprueba este ritmo!",
                    "Siento cómo aumenta mi poder...",
                    "¡Extraigan el bajo de esta melodía!",
                    "Todo marcha según el diseño del Sistema.",
                    "Mis Sombras marchan al compás."
                )
                "igris" -> listOf(
                    "Por el Monarca de las Sombras, ¡esta melodía es gloriosa!",
                    "Mis espadas se mueven al compás, mi Señor.",
                    "¡A sus órdenes, listo para el combate musical!",
                    "Esta resonancia alimenta mi lealtad eterna.",
                    "El ritmo de la batalla nunca se detiene."
                )
                "beru" -> listOf(
                    "¡KIEEEEH! ¡EL SOBERANO TIENE EL MEJOR GUSTO!",
                    "¡MÚSICA PARA AGRADAR A NUESTRO REY!",
                    "¡KIEEEEH! ¡DESTRUIREMOS AL ENEMIGO CON ESTE RITMO!",
                    "¡Hormigas soldado, bailad para el Monarca!",
                    "¡MI VIDA POR LA SINFONÍA DE LA COLMENA!"
                )
                else -> listOf(
                    "¡UAAAAGH! (Golpea su escudo al compás)",
                    "¡PUM! ¡CHAC! ¡PUM! (Pisa fuerte con ritmo)",
                    "¡DEFENSA TOTAL CONTRA EL SILENCIO!",
                    "¡RITMO DE CLASE TANQUE ACTIVO!"
                )
            }
            while (true) {
                delay(4000)
                currentDialogue = dialogues.random()
            }
        } else {
            currentDialogue = when (selectedChar) {
                "jinwoo" -> "Modo de entrenamiento. Selecciona un track para iniciar la canalización."
                "igris" -> "Esperando instrucciones de música, mi Señor."
                "beru" -> "¡KIEH! ¿Por qué se detuvo el glorioso coro?"
                else -> "Listo para resonar..."
            }
        }
    }

    // Animation constants
    val infiniteTransition = rememberInfiniteTransition(label = "PlayerAnims")
    
    // Character Pulsing Motion
    val rotation by infiniteTransition.animateFloat(
        initialValue = if (isPlayingAny) -6f else 0f,
        targetValue = if (isPlayingAny) 6f else 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "charRotation"
    )
    val scale by infiniteTransition.animateFloat(
        initialValue = if (isPlayingAny) 0.95f else 1.0f,
        targetValue = if (isPlayingAny) 1.08f else 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 300, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "charScale"
    )

    // Hologram expanding ring
    val ringScale by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.6f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = EaseOutQuad),
            repeatMode = RepeatMode.Restart
        ),
        label = "ringScale"
    )
    val ringAlpha by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = EaseOutQuad),
            repeatMode = RepeatMode.Restart
        ),
        label = "ringAlpha"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("shadow_player_tab"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- 1. THEMATIC HEADER ---
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
                border = BorderStroke(1.dp, DarkSlateVariant),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "REPRODUCTOR SINFÓNICO DE SOMBRAS",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp,
                        color = SoloBlueGlow,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Canaliza frecuencias acústicas para energizar a tus filas del Monarca.",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = RankEGray,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        // --- 2. THE ANIMATION STAGE (HERO PANEL) ---
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.Black.copy(alpha = 0.4f))
                    .border(1.5.dp, DarkSlateVariant, RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                // Background Hologram Circles
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val center = Offset(size.width / 2f, size.height / 2f + 15.dp.toPx())
                    val themeColor = when (selectedChar) {
                        "jinwoo" -> SoloBlue
                        "igris" -> SoloPurpleGlow
                        "beru" -> RankSOrange
                        else -> SoloWhite
                    }

                    // Static center spot
                    drawCircle(
                        color = themeColor,
                        radius = 65.dp.toPx(),
                        center = center,
                        alpha = 0.04f
                    )

                    // Expanding pulsating shockwaves
                    if (isPlayingAny) {
                        drawCircle(
                            color = themeColor,
                            radius = 65.dp.toPx() * ringScale,
                            center = center,
                            style = Stroke(width = 1.5.dp.toPx()),
                            alpha = ringAlpha * 0.4f
                        )
                        drawCircle(
                            color = themeColor,
                            radius = 65.dp.toPx() * (ringScale * 0.7f).coerceIn(0.5f, 2f),
                            center = center,
                            style = Stroke(width = 1f.toPx()),
                            alpha = ringAlpha * 0.2f
                        )
                    }
                }

                // Stage content
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxSize()
                ) {
                    // Floating Dialogue Speech Bubble
                    Box(
                        modifier = Modifier
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                Brush.horizontalGradient(
                                    listOf(
                                        DarkSlateCard,
                                        DarkSlateVariant
                                    )
                                )
                            )
                            .border(
                                1.dp,
                                when (selectedChar) {
                                    "jinwoo" -> SoloBlue.copy(alpha = 0.5f)
                                    "igris" -> SoloPurpleGlow.copy(alpha = 0.5f)
                                    "beru" -> RankSOrange.copy(alpha = 0.5f)
                                    else -> SoloWhite.copy(alpha = 0.3f)
                                },
                                RoundedCornerShape(8.dp)
                            )
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                            .align(Alignment.CenterHorizontally)
                    ) {
                        Text(
                            text = currentDialogue,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = SoloWhite,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth(0.85f)
                        )
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    // Character Avatar (Chibi or Custom drawing)
                    Box(
                        modifier = Modifier
                            .size(130.dp)
                            .graphicsLayer {
                                rotationZ = rotation
                                scaleX = scale
                                scaleY = scale
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        when (selectedChar) {
                            "jinwoo" -> {
                                Image(
                                    painter = painterResource(id = R.drawable.img_jinwoo_player_1783475975388),
                                    contentDescription = "Chibi Jin-woo",
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .clip(CircleShape)
                                        .border(2.dp, SoloBlueGlow, CircleShape),
                                    contentScale = ContentScale.Crop
                                )
                            }
                            "igris" -> {
                                Image(
                                    painter = painterResource(id = R.drawable.img_igris_player_1783475987141),
                                    contentDescription = "Chibi Igris",
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .clip(CircleShape)
                                        .border(2.dp, SoloPurpleGlow, CircleShape),
                                    contentScale = ContentScale.Crop
                                )
                            }
                            "beru" -> {
                                // Dynamic canvas drawing of Beru the Ant King
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .clip(CircleShape)
                                        .background(RankSOrange.copy(alpha = 0.15f))
                                        .border(2.dp, RankSOrange, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(
                                            imageVector = Icons.Default.AutoAwesome,
                                            contentDescription = null,
                                            tint = RankSOrange,
                                            modifier = Modifier.size(48.dp)
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "BERU",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Black,
                                            color = RankSOrange,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                            else -> {
                                // Chibi Iron the Giant Shield-wielder
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .clip(CircleShape)
                                        .background(SoloWhite.copy(alpha = 0.1f))
                                        .border(2.dp, SoloWhite, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(
                                            imageVector = Icons.Default.OfflineBolt,
                                            contentDescription = null,
                                            tint = SoloWhite,
                                            modifier = Modifier.size(48.dp)
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "IRON",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Black,
                                            color = SoloWhite,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    // --- REALTIME SPECTRUM VISUALIZER ---
                    val spectrumValues = if (isPlayingAny) {
                        if (isSynthPlaying) spectrumValuesState.value else {
                            // Generate simulated values for external audio/video playing
                            FloatArray(8) { k ->
                                val wave = sin(System.currentTimeMillis() / 150.0 + k).toFloat()
                                abs(wave) * 0.8f + (Math.random().toFloat() * 0.2f)
                            }
                        }
                    } else {
                        FloatArray(8) { 0.05f }
                    }

                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(40.dp)
                            .padding(horizontal = 24.dp)
                    ) {
                        val barCount = 8
                        val spacing = 8.dp.toPx()
                        val totalSpacing = spacing * (barCount - 1)
                        val barWidth = (size.width - totalSpacing) / barCount
                        val maxBarHeight = size.height

                        for (i in 0 until barCount) {
                            val amp = spectrumValues[i].coerceIn(0f, 1.2f)
                            val barHeight = (amp * maxBarHeight).coerceAtLeast(3.dp.toPx())
                            val x = i * (barWidth + spacing)
                            val y = size.height - barHeight

                            drawRoundRect(
                                brush = Brush.verticalGradient(
                                    colors = listOf(
                                        when (selectedChar) {
                                            "jinwoo" -> SoloBlueGlow
                                            "igris" -> SoloPurpleGlow
                                            "beru" -> RankSOrange
                                            else -> SoloWhite
                                        },
                                        when (selectedChar) {
                                            "jinwoo" -> SoloBlue
                                            "igris" -> SoloPurple
                                            "beru" -> Color(0xFFC2410C)
                                            else -> RankEGray
                                        }
                                    )
                                ),
                                topLeft = Offset(x, y),
                                size = Size(barWidth, barHeight),
                                cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
                            )
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
        }

        // --- 3. CHARACTER SELECTOR ROW ---
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "SELECCIONAR SOLDADO DE FRECUENCIA",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = RankEGray
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val characters = listOf(
                        Triple("jinwoo", "JIN-WOO", SoloBlueGlow),
                        Triple("igris", "IGRIS", SoloPurpleGlow),
                        Triple("beru", "BERU", RankSOrange),
                        Triple("iron", "IRON", SoloWhite)
                    )

                    characters.forEach { (id, name, color) ->
                        val isSelected = selectedChar == id
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) color.copy(alpha = 0.15f) else DarkSlateCard)
                                .border(
                                    width = if (isSelected) 1.5.dp else 1.dp,
                                    color = if (isSelected) color else DarkSlateVariant,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable { selectedChar = id }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = name,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                color = if (isSelected) color else RankEGray
                            )
                        }
                    }
                }
            }
        }

        // --- 4. CURRENT PLAYING CONTROLLER BANNER ---
        item {
            AnimatedVisibility(visible = isPlayingAny) {
                val currentTitle = when {
                    viewModel.playingPreloadedTrack != null -> viewModel.playingPreloadedTrack?.title ?: ""
                    playingMedia != null -> playingMedia.title
                    else -> "Transmisión de Sombras"
                }
                val currentComposer = when {
                    viewModel.playingPreloadedTrack != null -> viewModel.playingPreloadedTrack?.composer ?: ""
                    playingMedia != null -> "Sombra Recuperada (${playingMedia.sourcePlatform})"
                    else -> "Frecuencia del Sistema"
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
                    border = BorderStroke(1.5.dp, if (isSynthPlaying) SoloPurpleGlow else SoloBlueGlow),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "CANALIZANDO NÚCLEO ACTIVO",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Black,
                                color = if (isSynthPlaying) SoloPurpleGlow else SoloBlueGlow,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = currentTitle,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = SoloWhite,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = currentComposer,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = RankEGray
                            )
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Pause/Play Button (Only for Synth tracks and normal audio tracks)
                            if (viewModel.playingPreloadedTrack != null || (playingMedia != null && playingMedia.mimeType.contains("audio"))) {
                                IconButton(
                                    onClick = {
                                        if (viewModel.playingPreloadedTrack != null) {
                                            viewModel.stopPreloadedTrack()
                                        } else if (playingMedia != null) {
                                            onPlayMedia(playingMedia)
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Pause,
                                        contentDescription = "Pausar",
                                        tint = SoloBlue,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                            }
                            // Stop Button
                            IconButton(
                                onClick = {
                                    if (viewModel.playingPreloadedTrack != null) {
                                        viewModel.stopPreloadedTrack()
                                    } else {
                                        onStopAudio()
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Stop,
                                    contentDescription = "Detener",
                                    tint = Color.Red,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // --- 5. EPIDEMIC SYNTH TRACKS LIST ---
        item {
            Text(
                text = "CANTOS DEL SISTEMA (PREESTABLECIDOS)",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = RankEGray,
                modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
            )
        }

        items(viewModel.preloadedTracks) { track ->
            val isActive = viewModel.playingPreloadedTrack == track
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        if (playingMedia != null) onStopAudio()
                        if (isActive) {
                            viewModel.stopPreloadedTrack()
                        } else {
                            viewModel.playPreloadedTrack(track)
                        }
                    },
                colors = CardDefaults.cardColors(containerColor = if (isActive) DarkSlateVariant else DarkSlateCard),
                border = BorderStroke(1.dp, if (isActive) SoloBlueGlow else DarkSlateVariant),
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isActive) SoloBlue.copy(alpha = 0.2f) else DarkSlateVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isActive) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = if (isActive) SoloBlueGlow else RankEGray
                            )
                        }
                        Column {
                            Text(
                                text = track.title,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = if (isActive) SoloBlueGlow else SoloWhite
                            )
                            Text(
                                text = track.composer,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                color = RankEGray
                            )
                        }
                    }
                    Text(
                        text = track.duration,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = RankEGray
                    )
                }
            }
        }

        // --- 6. INTEGRATED VIDEO PLAYBACK BOX ---
        if (playingMedia != null && playingMedia.mimeType.contains("video")) {
            item {
                Text(
                    text = "REPRODUCIENDO VIDEO DE SOMBRA",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = RankEGray,
                    modifier = Modifier.padding(top = 8.dp)
                )
                
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.Black)
                        .border(1.5.dp, SoloBlueGlow, RoundedCornerShape(12.dp))
                ) {
                    Column {
                        // Native Video View
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(190.dp)
                        ) {
                            AndroidView(
                                factory = { ctx ->
                                    VideoView(ctx).apply {
                                        setVideoURI(Uri.fromFile(File(playingMedia.filePath)))
                                        setOnPreparedListener { mp ->
                                            mp.isLooping = true
                                            start()
                                        }
                                    }
                                },
                                update = { view ->
                                    view.setVideoURI(Uri.fromFile(File(playingMedia.filePath)))
                                    view.start()
                                },
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        // Video Stats Footer
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(DarkSlateCard)
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = playingMedia.title,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = SoloWhite,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = { onStopAudio() },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Cerrar",
                                    tint = Color.Red
                                )
                            }
                        }
                    }
                }
            }
        }

        // --- 7. RECLAIMED MEDIA FROM INVENTORY ---
        val downloadedAudios = mediaList.filter { it.mimeType.contains("audio") }
        if (downloadedAudios.isNotEmpty()) {
            item {
                Text(
                    text = "RECURSOS RECLAMADOS (INVENTARIO AUDIO)",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = RankEGray,
                    modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                )
            }

            items(downloadedAudios) { media ->
                val isActive = playingMedia == media
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            if (isSynthPlaying) viewModel.stopPreloadedTrack()
                            onPlayMedia(media)
                        },
                    colors = CardDefaults.cardColors(containerColor = if (isActive) DarkSlateVariant else DarkSlateCard),
                    border = BorderStroke(1.dp, if (isActive) SoloBlueGlow else DarkSlateVariant),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isActive) SoloPurple.copy(alpha = 0.2f) else DarkSlateVariant),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (isActive && isAudioPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = null,
                                    tint = if (isActive) SoloBlueGlow else RankEGray
                                )
                            }
                            Column {
                                Text(
                                    text = media.title,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = if (isActive) SoloBlueGlow else SoloWhite,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "Origen: ${media.sourcePlatform} • ${media.duration}",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp,
                                    color = RankEGray
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
