package com.example.ui.screen

import android.media.MediaPlayer
import android.net.Uri
import android.widget.VideoView
import android.util.Log
import androidx.compose.ui.draw.alpha
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.PauseCircle
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.OfflineBolt
import com.example.data.service.MediaMetadata
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.example.R
import com.example.data.database.ChatMessage
import com.example.data.database.DownloadedMedia
import com.example.data.database.HunterStats
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppViewModel
import kotlinx.coroutines.delay
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

fun generateQRCodeBitmap(content: String, size: Int): android.graphics.Bitmap? {
    return try {
        val bitMatrix = com.google.zxing.MultiFormatWriter().encode(
            content,
            com.google.zxing.BarcodeFormat.QR_CODE,
            size,
            size
        )
        val width = bitMatrix.width
        val height = bitMatrix.height
        val pixels = IntArray(width * height)
        for (y in 0 until height) {
            val offset = y * width
            for (x in 0 until width) {
                pixels[offset + x] = if (bitMatrix.get(x, y)) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
            }
        }
        val bitmap = android.graphics.Bitmap.createBitmap(width, height, android.graphics.Bitmap.Config.ARGB_8888)
        bitmap.setPixels(pixels, 0, width, 0, 0, width, height)
        bitmap
    } catch (e: Exception) {
        e.printStackTrace()
        null
    }
}

@Composable
fun MainDashboard(
    modifier: Modifier = Modifier,
    viewModel: AppViewModel = viewModel()
) {
    val stats by viewModel.hunterStats.collectAsState()
    val mediaList by viewModel.downloadedMedia.collectAsState()
    val chatLogs by viewModel.chatMessages.collectAsState()
    val context = LocalContext.current

    // Navigation Tab state
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf(
        TabItem("SISTEMA", Icons.Default.Dashboard),
        TabItem("SHADOW LINK", Icons.Default.QrCode),
        TabItem("EXTRACTOR", Icons.Default.Download),
        TabItem("INVENTARIO", Icons.Default.Inventory),
        TabItem("REPRODUCTOR", Icons.Default.PlayCircle)
    )

    // Current playing media states
    var playingMedia by remember { mutableStateOf<DownloadedMedia?>(null) }
    var isAudioPlaying by remember { mutableStateOf(false) }
    val mediaPlayer = remember { MediaPlayer() }

    // Clean up mediaPlayer on dispose
    DisposableEffect(Unit) {
        onDispose {
            mediaPlayer.release()
        }
    }

    val playMediaLambda: (DownloadedMedia) -> Unit = { media ->
        viewModel.stopPreloadedTrack()
        if (media.mimeType.contains("audio")) {
            if (playingMedia == media) {
                if (mediaPlayer.isPlaying) {
                    mediaPlayer.pause()
                    isAudioPlaying = false
                } else {
                    mediaPlayer.start()
                    isAudioPlaying = true
                }
            } else {
                playingMedia = media
                try {
                    mediaPlayer.reset()
                    mediaPlayer.setDataSource(context, Uri.fromFile(File(media.filePath)))
                    mediaPlayer.prepare()
                    mediaPlayer.start()
                    isAudioPlaying = true
                } catch (e: Exception) {
                    Log.e("Inventory", "Error playing media: ${e.message}")
                    isAudioPlaying = false
                }
            }
        } else {
            playingMedia = media
            isAudioPlaying = false
            mediaPlayer.reset()
        }
    }

    val stopMediaLambda: () -> Unit = {
        mediaPlayer.stop()
        isAudioPlaying = false
        playingMedia = null
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                containerColor = AbyssBlack,
                tonalElevation = 8.dp,
                modifier = Modifier
                    .border(1.dp, DarkSlateVariant, RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("system_bottom_nav")
            ) {
                tabs.forEachIndexed { index, tab ->
                    val isSelected = selectedTab == index
                    val activeColor = SoloBlue
                    val inactiveColor = RankEGray
                    val iconScale by animateFloatAsState(
                        targetValue = if (isSelected) 1.2f else 1.0f,
                        animationSpec = spring(dampingRatio = 0.6f, stiffness = 300f),
                        label = "iconScale"
                    )

                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { selectedTab = index },
                        icon = {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = tab.title,
                                tint = if (isSelected) activeColor else inactiveColor,
                                modifier = Modifier.graphicsLayer(scaleX = iconScale, scaleY = iconScale)
                            )
                        },
                        label = {
                            Text(
                                text = tab.title,
                                color = if (isSelected) activeColor else inactiveColor,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = DarkSlateVariant
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(AbyssBlack)
                .padding(innerPadding)
        ) {
            // Ambient space grid drawing background
            Canvas(modifier = Modifier.fillMaxSize()) {
                val gridSpacing = 60.dp.toPx()
                val lineAlpha = 0.05f

                // Horizontal Grid lines
                var y = 0f
                while (y < size.height) {
                    drawLine(
                        color = SoloBlue,
                        start = Offset(0f, y),
                        end = Offset(size.width, y),
                        strokeWidth = 1f,
                        alpha = lineAlpha
                    )
                    y += gridSpacing
                }

                // Vertical Grid lines
                var x = 0f
                while (x < size.width) {
                    drawLine(
                        color = SoloBlue,
                        start = Offset(x, 0f),
                        end = Offset(x, size.height),
                        strokeWidth = 1f,
                        alpha = lineAlpha
                    )
                    x += gridSpacing
                }

                // Glowing background spot
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(SoloPurple.copy(alpha = 0.12f), Color.Transparent),
                        center = Offset(size.width / 2f, size.height / 3f),
                        radius = size.width * 0.8f
                    )
                )
            }

            val infiniteTransition = rememberInfiniteTransition(label = "BackgroundMotion")
            val translationX by infiniteTransition.animateFloat(
                initialValue = -35f,
                targetValue = 35f,
                animationSpec = infiniteRepeatable(
                    animation = tween(durationMillis = 16000, easing = LinearEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "translationX"
            )
            val translationY by infiniteTransition.animateFloat(
                initialValue = -20f,
                targetValue = 20f,
                animationSpec = infiniteRepeatable(
                    animation = tween(durationMillis = 20000, easing = LinearEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "translationY"
            )
            val scale by infiniteTransition.animateFloat(
                initialValue = 1.08f,
                targetValue = 1.20f,
                animationSpec = infiniteRepeatable(
                    animation = tween(durationMillis = 24000, easing = LinearEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "scale"
            )

            // Image Hero Banner Background (glowing neon BMW in motion)
            Image(
                painter = painterResource(id = R.drawable.img_bmw_background_1783461008544),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        this.translationX = translationX
                        this.translationY = translationY
                        this.scaleX = scale
                        this.scaleY = scale
                    }
                    .alpha(0.24f), // Enhanced alpha to fully appreciate the neon styling and gorgeous sports car details while maintaining contrast
                contentScale = ContentScale.Crop
            )

            // Dynamic view loading depending on active tab
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                // Glow Header System Overlay
                SystemStatsHeader(stats = stats)

                Spacer(modifier = Modifier.height(12.dp))

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    Crossfade(
                        targetState = selectedTab,
                        animationSpec = tween(durationMillis = 450, easing = FastOutSlowInEasing),
                        label = "tabTransition"
                    ) { targetTab ->
                        when (targetTab) {
                            0 -> DashboardTab(
                                stats = stats,
                                mediaCount = mediaList.size,
                                chatCount = chatLogs.size,
                                onNavigateToExtractor = { selectedTab = 2 },
                                onNavigateToWhatsApp = { selectedTab = 1 }
                            )
                            1 -> ShadowLinkTab(
                                viewModel = viewModel,
                                chatLogs = chatLogs,
                                stats = stats
                            )
                            2 -> ExtractorTab(
                                viewModel = viewModel
                            )
                            3 -> InventoryTab(
                                mediaList = mediaList,
                                playingMedia = playingMedia,
                                isAudioPlaying = isAudioPlaying,
                                onPlayMedia = { media ->
                                    if (media.mimeType.contains("audio")) {
                                        if (playingMedia == media) {
                                            if (mediaPlayer.isPlaying) {
                                                mediaPlayer.pause()
                                                isAudioPlaying = false
                                            } else {
                                                mediaPlayer.start()
                                                isAudioPlaying = true
                                            }
                                        } else {
                                            playingMedia = media
                                            try {
                                                mediaPlayer.reset()
                                                mediaPlayer.setDataSource(context, Uri.fromFile(File(media.filePath)))
                                                mediaPlayer.prepare()
                                                mediaPlayer.start()
                                                isAudioPlaying = true
                                            } catch (e: Exception) {
                                                Log.e("Inventory", "Error playing media: ${e.message}")
                                                isAudioPlaying = false
                                            }
                                        }
                                    } else {
                                        playingMedia = media
                                        isAudioPlaying = false
                                        mediaPlayer.reset()
                                    }
                                },
                                onDeleteMedia = { media ->
                                    if (playingMedia == media) {
                                        mediaPlayer.stop()
                                        playingMedia = null
                                        isAudioPlaying = false
                                    }
                                    viewModel.deleteMedia(media)
                                },
                                onStopAudio = {
                                    mediaPlayer.stop()
                                    isAudioPlaying = false
                                    playingMedia = null
                                }
                            )
                        }
                    }
                }
            }

            // LEVEL UP FULL SCREEN OVERLAY
            AnimatedVisibility(
                visible = viewModel.showLevelUpOverlay,
                enter = fadeIn() + scaleIn(initialScale = 0.8f),
                exit = fadeOut() + scaleOut()
            ) {
                LevelUpOverlay(
                    oldLevel = viewModel.previousLevel,
                    newLevel = stats.level,
                    rank = stats.rank,
                    onDismiss = { viewModel.showLevelUpOverlay = false }
                )
            }

            // MEDIA EXTRACTION FULL PANEL MODAL
            AnimatedVisibility(
                visible = viewModel.extractionState == "EXTRACTING" || 
                          viewModel.extractionState == "AR ARISING" || 
                          viewModel.extractionState == "DOWNLOAD_PROGRESS",
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                ExtractionOverlay(
                    state = viewModel.extractionState,
                    progress = viewModel.downloadProgress,
                    metadata = viewModel.extractedMetadata
                )
            }
        }
    }
}

data class TabItem(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

// --- SYSTEM HEADER PANEL (SOLO LEVELING STYLE) ---
@Composable
fun SystemStatsHeader(stats: HunterStats) {
    // 1. Animated EXP progress
    val progressFraction = (stats.exp.toFloat() / stats.requiredExp.toFloat()).coerceIn(0f, 1f)
    val animatedProgress by animateFloatAsState(
        targetValue = progressFraction,
        animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
        label = "expProgress"
    )

    // 2. Pulsing indicator dot
    val infiniteTransition = rememberInfiniteTransition(label = "HeaderAnimations")
    val dotAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "dotAlpha"
    )

    // 3. Magical shifting gradient offset for the EXP bar
    val gradientOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 5000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "gradientOffset"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(DarkSlateCard.copy(alpha = 0.85f))
            .border(1.dp, SoloBlue.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(RoundedCornerShape(50))
                                .background(
                                    if (stats.botStatus == "CONNECTED") SoloBlueGlow.copy(alpha = dotAlpha) 
                                    else RankEGray.copy(alpha = dotAlpha)
                                )
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "SOLO LEVELING - SISTEMA DE BOT",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = SoloBlue
                        )
                    }
                    Text(
                        text = "ESTADO: ${stats.botStatus}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        color = when (stats.botStatus) {
                            "CONNECTED" -> SoloBlueGlow
                            "QR_SHOWN" -> GoldAccent
                            "INITIALIZING" -> SoloPurpleGlow
                            else -> RankEGray
                        }
                    )
                }

                // Rank glowing badge with pulsing glow border
                val badgePulseColor by infiniteTransition.animateColor(
                    initialValue = SoloPurpleGlow,
                    targetValue = SoloPurpleGlow.copy(alpha = 0.4f),
                    animationSpec = infiniteRepeatable(
                        animation = tween(durationMillis = 1500, easing = LinearEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "badgePulseColor"
                )

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(SoloPurple, DarkSlateVariant)
                            )
                        )
                        .border(1.dp, badgePulseColor, RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = stats.rank.uppercase(),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = SoloWhite
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Level & Experience Progression row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "NV",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = SoloBlue,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${stats.level}",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Black,
                        color = SoloWhite,
                        fontSize = 18.sp
                    )
                }

                // Custom EXP Slider/Bar with animated progress and flow
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(10.dp)
                        .padding(horizontal = 12.dp)
                        .clip(RoundedCornerShape(50))
                        .background(DarkSlateVariant)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(animatedProgress)
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(SoloBlue, SoloPurple, SoloBlue),
                                    startX = gradientOffset,
                                    endX = gradientOffset + 500f
                                )
                            )
                    )
                }

                Text(
                    text = "${stats.exp}/${stats.requiredExp} EXP",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = RankEGray
                )
            }
        }
    }
}

// --- TAB 1: DASHBOARD STATS & QUESTS ---
@Composable
fun DashboardTab(
    stats: HunterStats,
    mediaCount: Int,
    chatCount: Int,
    onNavigateToExtractor: () -> Unit,
    onNavigateToWhatsApp: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "DashboardTabAnims")
    
    // Breathing alpha for System Warning Card border glow
    val warningGlowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "warningGlowAlpha"
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Welcome notification card styled like classical system quest logs
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(DarkSlateCard.copy(alpha = 0.9f))
                    .border(
                        BorderStroke(
                            1.dp,
                            Brush.linearGradient(
                                colors = listOf(
                                    SoloPurpleGlow.copy(alpha = warningGlowAlpha),
                                    Color.Transparent,
                                    SoloBlueGlow.copy(alpha = warningGlowAlpha)
                                )
                            )
                        ),
                        RoundedCornerShape(12.dp)
                    )
                    .padding(16.dp)
            ) {
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = RankSOrange,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "NOTIFICACIÓN DEL SISTEMA",
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Black,
                                color = SoloWhite,
                                letterSpacing = 1.sp
                            )
                        }
                        
                        // Tiny pulsing indicator dot
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(RoundedCornerShape(50))
                                .background(RankSOrange)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Has sido elegido como el Cazador de Sombras de Medios. Vincula tu WhatsApp escaneando el código QR para que tu bot canalice el poder del Monarca y responda a tus seguidores. Extrae archivos multimedia al instante.",
                        fontSize = 13.sp,
                        color = RankEGray,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        // Active stats summary grid
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    modifier = Modifier.weight(1f),
                    title = "SOLDADOS DE SOMBRA",
                    value = "${stats.shadowSoldiersCount}",
                    desc = "Medios descargados/chats",
                    icon = Icons.Default.Groups,
                    color = SoloBlue
                )
                StatCard(
                    modifier = Modifier.weight(1f),
                    title = "CANAL DE WHATSAPP",
                    value = if (stats.botStatus == "CONNECTED") "ACTIVO" else "OFFLINE",
                    desc = stats.botName,
                    icon = Icons.Default.Message,
                    color = if (stats.botStatus == "CONNECTED") SoloBlueGlow else RankEGray
                )
            }
        }

        // LEVELING QUESTS (MANDATORY IN SOLO LEVELING THEMES)
        item {
            Text(
                text = "DAILY QUESTS (MISIONES DIARIAS)",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                color = SoloBlue,
                fontSize = 12.sp,
                letterSpacing = 2.sp,
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }

        // Daily Quest 1: Setup config
        item {
            QuestItemCard(
                title = "Establecer Directrices del Monarca",
                desc = "Configura o edita el prompt del bot en SHADOW LINK",
                reward = "+20 EXP",
                isCompleted = stats.systemInstruction.isNotEmpty() && stats.botName.isNotEmpty(),
                onClick = onNavigateToWhatsApp,
                delayMillis = 100
            )
        }

        // Daily Quest 2: Link QR code
        item {
            QuestItemCard(
                title = "Invocar Canal Holográfico (Escanear QR)",
                desc = "Establece la conexión vinculando tu WhatsApp",
                reward = "+50 EXP",
                isCompleted = stats.botStatus == "CONNECTED",
                onClick = onNavigateToWhatsApp,
                delayMillis = 250
            )
        }

        // Daily Quest 3: Extraer sombra
        item {
            QuestItemCard(
                title = "Extraer Núcleo de Mana (Descargar Video/Música)",
                desc = "Pega una URL y realza su sombra en el EXTRACTOR",
                reward = "+35 EXP",
                isCompleted = stats.downloadCount > 0,
                onClick = onNavigateToExtractor,
                delayMillis = 400
            )
        }
    }
}

@Composable
fun StatCard(
    modifier: Modifier = Modifier,
    title: String,
    value: String,
    desc: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    onClick: (() -> Unit)? = null
) {
    var isVisible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        isVisible = true
    }
    
    val alphaAnim by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(durationMillis = 800, easing = FastOutSlowInEasing),
        label = "alpha"
    )
    val offsetYAnim by animateDpAsState(
        targetValue = if (isVisible) 0.dp else 16.dp,
        animationSpec = tween(durationMillis = 800, easing = FastOutSlowInEasing),
        label = "offsetY"
    )

    // Pulsing inner glow if status is active (e.g. connected status)
    val infiniteTransition = rememberInfiniteTransition(label = "StatCardPulse")
    val pulseGlow by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseGlow"
    )

    val borderStrokeColor = if (value == "ACTIVO") {
        color.copy(alpha = pulseGlow)
    } else {
        DarkSlateVariant
    }

    Box(
        modifier = modifier
            .offset(y = offsetYAnim)
            .graphicsLayer(alpha = alphaAnim)
            .clip(RoundedCornerShape(12.dp))
            .background(DarkSlateCard.copy(alpha = 0.8f))
            .border(1.dp, borderStrokeColor, RoundedCornerShape(12.dp))
            .then(
                if (onClick != null) Modifier.clickable { onClick() } else Modifier
            )
            .padding(14.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = RankEGray
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color.copy(alpha = 0.8f),
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = value,
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                color = SoloWhite
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = desc,
                fontSize = 11.sp,
                color = RankEGray,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun QuestItemCard(
    title: String,
    desc: String,
    reward: String,
    isCompleted: Boolean,
    onClick: () -> Unit,
    delayMillis: Int = 0
) {
    var isVisible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(delayMillis.toLong())
        isVisible = true
    }

    val alphaAnim by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(durationMillis = 600, easing = FastOutSlowInEasing),
        label = "alpha"
    )
    val offsetYAnim by animateDpAsState(
        targetValue = if (isVisible) 0.dp else 12.dp,
        animationSpec = tween(durationMillis = 600, easing = FastOutSlowInEasing),
        label = "offsetY"
    )

    // Breathing glow animation for completed quest border
    val infiniteTransition = rememberInfiniteTransition(label = "QuestGlow")
    val borderAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "borderAlpha"
    )

    val borderStrokeColor = if (isCompleted) {
        SoloBlue.copy(alpha = borderAlpha)
    } else {
        DarkSlateVariant
    }

    val cardBackground = if (isCompleted) {
        DarkSlateCard.copy(alpha = 0.85f)
    } else {
        DarkSlateCard.copy(alpha = 0.6f)
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .offset(y = offsetYAnim)
            .graphicsLayer(alpha = alphaAnim)
            .clip(RoundedCornerShape(10.dp))
            .background(cardBackground)
            .border(
                1.dp,
                borderStrokeColor,
                RoundedCornerShape(10.dp)
            )
            .clickable(onClick = onClick)
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isCompleted) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = SoloBlue,
                            modifier = Modifier
                                .size(14.dp)
                                .padding(end = 4.dp)
                        )
                    }
                    Text(
                        text = title,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = if (isCompleted) SoloBlueGlow else SoloWhite,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = desc,
                    fontSize = 11.sp,
                    color = RankEGray,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = reward,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = GoldAccent,
                    modifier = Modifier.padding(end = 8.dp)
                )
                Box(
                    modifier = Modifier
                        .size(18.dp)
                        .border(
                            1.dp,
                            if (isCompleted) SoloBlue else RankEGray,
                            RoundedCornerShape(4.dp)
                        )
                        .background(
                            if (isCompleted) SoloBlue.copy(alpha = 0.2f) else Color.Transparent
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isCompleted) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = SoloBlue,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }
    }
}

// --- TAB 2: WHATSAPP SHADOW LINK CONSOLE (QR & SYSTEM PROMPTS) ---
@Composable
fun ShadowLinkTab(
    viewModel: AppViewModel,
    chatLogs: List<ChatMessage>,
    stats: HunterStats
) {
    val context = LocalContext.current
    var showPromptSettings by remember { mutableStateOf(false) }

    val infiniteTransition = rememberInfiniteTransition(label = "ShadowLinkPulseAnims")
    val buttonScale by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "buttonScale"
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Toggle configurations/instructions button
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "WHATSAPP DE MEDIOS",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    color = SoloWhite,
                    fontSize = 14.sp
                )

                Button(
                    onClick = { showPromptSettings = !showPromptSettings },
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSlateCard),
                    border = BorderStroke(1.dp, SoloBlue),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.height(32.dp)
                ) {
                    Icon(
                        imageVector = if (showPromptSettings) Icons.Default.Close else Icons.Default.Edit,
                        contentDescription = null,
                        tint = SoloBlue,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (showPromptSettings) "CERRAR CONFIG" else "CONFIG MOTIVO",
                        fontSize = 11.sp,
                        color = SoloBlue,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Active editable configs
        if (showPromptSettings) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(DarkSlateCard)
                        .border(1.dp, SoloPurple.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "HOLOGRÁFICAS DEL SISTEMA",
                            color = SoloPurpleGlow,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )

                        // Bot name input
                        OutlinedTextField(
                            value = viewModel.botNameInput,
                            onValueChange = { viewModel.botNameInput = it },
                            label = { Text("Nombre del Bot Sombra", color = RankEGray) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SoloBlue,
                                unfocusedBorderColor = DarkSlateVariant,
                                focusedTextColor = SoloWhite,
                                unfocusedTextColor = SoloWhite
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        // System prompt input
                        OutlinedTextField(
                            value = viewModel.systemInstructionInput,
                            onValueChange = { viewModel.systemInstructionInput = it },
                            label = { Text("Instrucción del Sistema (Personalidad)", color = RankEGray) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SoloBlue,
                                unfocusedBorderColor = DarkSlateVariant,
                                focusedTextColor = SoloWhite,
                                unfocusedTextColor = SoloWhite
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 3
                        )

                        // Action SAVE button
                        Button(
                            onClick = {
                                viewModel.updateBotConfig(viewModel.botNameInput, viewModel.systemInstructionInput)
                                showPromptSettings = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SoloPurple),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                "RE-CALIBRAR DIRECTRICES",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // ACTIVE STATUS / QR SCREEN
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(DarkSlateCard.copy(alpha = 0.8f))
                    .border(1.dp, DarkSlateVariant, RoundedCornerShape(12.dp))
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Futuristic connection mode selector (visible unless already connected)
                    if (stats.botStatus != "CONNECTED") {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(DarkSlateVariant, RoundedCornerShape(8.dp))
                                .padding(4.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            val modes = listOf("QR" to "CÓDIGO QR", "PAIRING_CODE" to "8 DÍGITOS")
                            modes.forEach { (mode, label) ->
                                val isSelected = viewModel.connectionMode == mode
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isSelected) SoloBlue.copy(alpha = 0.15f) else Color.Transparent)
                                        .border(1.dp, if (isSelected) SoloBlue else Color.Transparent, RoundedCornerShape(6.dp))
                                        .clickable { viewModel.setMode(mode) }
                                        .padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = label,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = if (isSelected) SoloBlue else RankEGray,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }

                    if (viewModel.isConnectingBot) {
                        // IMMERSIVE CONNECTION STEPS PROGRESS
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.padding(vertical = 24.dp)
                        ) {
                            CircularProgressIndicator(
                                color = if (viewModel.connectionMode == "QR") SoloBlue else SoloPurpleGlow,
                                strokeWidth = 3.dp,
                                modifier = Modifier.size(48.dp)
                            )
                            
                            Text(
                                text = "ANCLANDO SISTEMA SOMBRA",
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = SoloWhite,
                                fontSize = 13.sp,
                                letterSpacing = 2.sp
                            )
                            
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(AbyssBlack.copy(alpha = 0.6f))
                                    .border(1.dp, if (viewModel.connectionMode == "QR") SoloBlue.copy(alpha = 0.3f) else SoloPurpleGlow.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                    .padding(14.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = viewModel.connectionStepText,
                                    color = if (viewModel.connectionMode == "QR") SoloBlueGlow else SoloPurpleGlow,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    textAlign = TextAlign.Center,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    } else {
                        // Standard state machine for setup
                        when (stats.botStatus) {
                            "DISCONNECTED" -> {
                                if (viewModel.connectionMode == "QR") {
                                    Icon(
                                        imageVector = Icons.Default.QrCodeScanner,
                                        contentDescription = null,
                                        tint = SoloBlue,
                                        modifier = Modifier.size(56.dp)
                                    )
                                    Text(
                                        text = "CALIBRAR ENLACE WHATSAPP (SIMULADO)",
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 13.sp,
                                        color = SoloWhite
                                    )

                                    Text(
                                        text = "Inicia la simulación holográfica para vincular tu WhatsApp Sombra. Despliega el anclaje y presiona 'ESCANEAR QR'.",
                                        color = RankEGray,
                                        fontSize = 12.sp,
                                        textAlign = TextAlign.Center
                                    )

                                    Button(
                                        onClick = { viewModel.startWhatsAppSetup() },
                                        colors = ButtonDefaults.buttonColors(containerColor = SoloBlue),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.testTag("setup_linked_button")
                                    ) {
                                        if (viewModel.isInitializingBot) {
                                            CircularProgressIndicator(color = AbyssBlack, modifier = Modifier.size(18.dp))
                                        } else {
                                            Text(
                                                "DESPLEGAR ANCLAJE QR",
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Link,
                                        contentDescription = null,
                                        tint = SoloPurpleGlow,
                                        modifier = Modifier.size(56.dp)
                                    )
                                    Text(
                                        text = "SINCRO-ANCLAJE DE 8 DÍGITOS (SIMULADO)",
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 13.sp,
                                        color = SoloWhite
                                    )

                                    Text(
                                        text = "Sincroniza un número telefónico simulado para obtener un código de vinculación holográfico de 8 dígitos.",
                                        color = RankEGray,
                                        fontSize = 11.sp,
                                        textAlign = TextAlign.Center
                                    )

                                    Column(
                                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = "Número de WhatsApp móvil",
                                            color = SoloWhite,
                                            fontSize = 11.sp,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold
                                        )
                                        OutlinedTextField(
                                            value = viewModel.pairingPhoneNumber,
                                            onValueChange = { viewModel.pairingPhoneNumber = it },
                                            placeholder = { Text("ej: +51987654321", color = RankEGray.copy(alpha = 0.5f)) },
                                            leadingIcon = {
                                                Icon(
                                                    imageVector = Icons.Default.Phone,
                                                    contentDescription = null,
                                                    tint = SoloPurpleGlow,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            },
                                            textStyle = TextStyle(fontFamily = FontFamily.Monospace, color = SoloWhite, fontSize = 13.sp),
                                            singleLine = true,
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                            colors = OutlinedTextFieldDefaults.colors(
                                                focusedTextColor = SoloWhite,
                                                unfocusedTextColor = SoloWhite,
                                                focusedContainerColor = AbyssBlack.copy(alpha = 0.6f),
                                                unfocusedContainerColor = AbyssBlack.copy(alpha = 0.4f),
                                                focusedBorderColor = SoloPurpleGlow,
                                                unfocusedBorderColor = DarkSlateVariant,
                                                focusedLabelColor = SoloPurpleGlow,
                                                unfocusedLabelColor = RankEGray,
                                                cursorColor = SoloPurpleGlow
                                            ),
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }

                                    Button(
                                        onClick = { viewModel.startPairingCodeSetup() },
                                        enabled = viewModel.pairingPhoneNumber.isNotBlank() && !viewModel.isGeneratingPairingCode,
                                        colors = ButtonDefaults.buttonColors(containerColor = SoloPurpleGlow, disabledContainerColor = DarkSlateVariant),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.testTag("setup_pairing_code_button")
                                    ) {
                                        if (viewModel.isGeneratingPairingCode) {
                                            CircularProgressIndicator(color = SoloWhite, modifier = Modifier.size(18.dp))
                                        } else {
                                            Text(
                                                "GENERAR CÓDIGO DE 8 DÍGITOS",
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                color = if (viewModel.pairingPhoneNumber.isNotBlank()) SoloWhite else RankEGray
                                            )
                                        }
                                    }
                                }
                            }

                            "INITIALIZING" -> {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(12.dp),
                                    modifier = Modifier.padding(vertical = 16.dp)
                                ) {
                                    CircularProgressIndicator(
                                        color = if (viewModel.connectionMode == "QR") SoloBlue else SoloPurpleGlow,
                                        modifier = Modifier.size(36.dp)
                                    )
                                    Text(
                                        text = if (viewModel.connectionMode == "QR") {
                                            "ABRIENDO CANAL DIMENSIONAL (QR)..."
                                        } else {
                                            "CALCULANDO ANCLAJE DE 8 DÍGITOS..."
                                        },
                                        fontFamily = FontFamily.Monospace,
                                        color = SoloWhite,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            "QR_SHOWN" -> {
                                if (viewModel.connectionMode == "QR") {
                                    // EYE-CATCHING TOP WARNING TO PREVENT REAL SCANNING
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(RankSOrange.copy(alpha = 0.2f))
                                            .border(1.5.dp, RankSOrange, RoundedCornerShape(10.dp))
                                            .padding(12.dp)
                                    ) {
                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    imageVector = Icons.Default.Warning,
                                                    contentDescription = null,
                                                    tint = RankSOrange,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = "⚠️ ¡ADVERTENCIA DE SIMULACIÓN!",
                                                    color = RankSOrange,
                                                    fontSize = 11.sp,
                                                    fontFamily = FontFamily.Monospace,
                                                    fontWeight = FontWeight.Black
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(
                                                text = "Este sistema es una recreación temática de Solo Leveling. NO escanees este código con tu WhatsApp real o WhatsApp Web, ya que mostrará error de 'Código QR no válido'.\n\nPara conectarlo en este simulador virtual, simplemente presiona el botón brillante de abajo: '⚡ AUTO-CONECTAR SIN ESCANEAR'.",
                                                color = SoloWhite,
                                                fontSize = 11.sp,
                                                fontFamily = FontFamily.Monospace,
                                                lineHeight = 14.sp
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))

                                    Text(
                                        text = "SISTEMA DE ENLACE (SIMULACIÓN)",
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Black,
                                        color = SoloBlue,
                                        fontSize = 13.sp,
                                        letterSpacing = 1.sp
                                    )

                                    // Hologram glowing QR frame with laser scanner sweeping animation and WATERMARK OVERLAY
                                    Box(
                                        modifier = Modifier
                                            .size(200.dp)
                                            .border(2.dp, SoloBlueGlow, RoundedCornerShape(12.dp))
                                            .background(Color.White)
                                            .padding(12.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        viewModel.qrCodeUrl?.let { url ->
                                            val qrBitmap = remember(url) { generateQRCodeBitmap(url, 400) }
                                            if (qrBitmap != null) {
                                                Box(modifier = Modifier.fillMaxSize()) {
                                                    Image(
                                                        bitmap = qrBitmap.asImageBitmap(),
                                                        contentDescription = "WhatsApp QR Connection Token",
                                                        modifier = Modifier
                                                            .fillMaxSize()
                                                            .graphicsLayer(alpha = 0.4f) // Dim QR code
                                                    )
                                                    
                                                    // BIG RED WATERMARK OVERLAY
                                                    Box(
                                                        modifier = Modifier
                                                            .fillMaxSize()
                                                            .background(Color.Black.copy(alpha = 0.15f)),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Text(
                                                            text = "SIMULADOR",
                                                            color = Color.Red,
                                                            fontWeight = FontWeight.Black,
                                                            fontSize = 22.sp,
                                                            fontFamily = FontFamily.Monospace,
                                                            modifier = Modifier
                                                                .border(2.dp, Color.Red, RoundedCornerShape(4.dp))
                                                                .background(Color.Black.copy(alpha = 0.85f))
                                                                .padding(horizontal = 8.dp, vertical = 2.dp)
                                                                .graphicsLayer(rotationZ = -15f)
                                                        )
                                                    }

                                                    // Holographic laser scanner sweeping animation
                                                    val laserTransition = rememberInfiniteTransition(label = "LaserScanner")
                                                    val laserY by laserTransition.animateFloat(
                                                        initialValue = 0f,
                                                        targetValue = 1f,
                                                        animationSpec = infiniteRepeatable(
                                                            animation = tween(durationMillis = 2200, easing = LinearEasing),
                                                            repeatMode = RepeatMode.Reverse
                                                        ),
                                                        label = "laserY"
                                                    )
                                                    
                                                    Canvas(modifier = Modifier.fillMaxSize()) {
                                                        val y = size.height * laserY
                                                        drawLine(
                                                            color = SoloBlue,
                                                            start = Offset(0f, y),
                                                            end = Offset(size.width, y),
                                                            strokeWidth = 3.dp.toPx()
                                                        )
                                                    }
                                                }
                                            } else {
                                                Text(
                                                    "Error al generar QR\nOprime CANCELAR y re-intenta",
                                                    color = Color.Black,
                                                    fontSize = 11.sp,
                                                    textAlign = TextAlign.Center,
                                                    fontFamily = FontFamily.Monospace
                                                )
                                            }
                                        } ?: Text(
                                            "Cargando anclaje...\nOprime CANCELAR y re-intenta",
                                            color = Color.Black,
                                            fontSize = 11.sp,
                                            textAlign = TextAlign.Center,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }

                                    Text(
                                        text = "Presiona el botón de abajo para canalizar el anclaje automático virtual.",
                                        color = SoloBlueGlow,
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        textAlign = TextAlign.Center
                                    )
                                } else {
                                    Text(
                                        text = "SINCRO-CÓDIGO DE 8 DÍGITOS",
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Black,
                                        color = SoloPurpleGlow,
                                        fontSize = 13.sp,
                                        letterSpacing = 1.sp
                                    )

                                    if (viewModel.pairingPhoneNumber.isNotBlank()) {
                                        Text(
                                            text = "VINCULANDO AL NÚMERO: ${viewModel.pairingPhoneNumber}",
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            color = SoloWhite,
                                            fontSize = 11.sp
                                        )
                                    }

                                    // Hologram glowing Pairing Code box with custom stylized cells
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(12.dp))
                                            .border(2.dp, SoloPurpleGlow, RoundedCornerShape(12.dp))
                                            .background(DarkSlateVariant.copy(alpha = 0.5f))
                                            .padding(16.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        viewModel.pairingCode?.let { code ->
                                            Row(
                                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                code.forEach { char ->
                                                    if (char == '-') {
                                                        Text(
                                                            text = "-",
                                                            color = SoloPurpleGlow,
                                                            fontSize = 24.sp,
                                                            fontWeight = FontWeight.Black,
                                                            fontFamily = FontFamily.Monospace
                                                        )
                                                    } else {
                                                        Box(
                                                            modifier = Modifier
                                                                .size(width = 32.dp, height = 44.dp)
                                                                .clip(RoundedCornerShape(6.dp))
                                                                .background(AbyssBlack)
                                                                .border(1.5.dp, SoloPurpleGlow, RoundedCornerShape(6.dp)),
                                                            contentAlignment = Alignment.Center
                                                        ) {
                                                            Text(
                                                                text = char.toString(),
                                                                color = SoloBlue,
                                                                fontSize = 20.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                fontFamily = FontFamily.Monospace
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                        } ?: Text(
                                            "Generando código...",
                                            color = RankEGray,
                                            fontSize = 12.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }

                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(SoloPurpleGlow.copy(alpha = 0.15f))
                                            .border(1.dp, SoloPurpleGlow.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                                            .padding(10.dp)
                                    ) {
                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    imageVector = Icons.Default.Info,
                                                    contentDescription = null,
                                                    tint = SoloPurpleGlow,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = "ANCLAJE DE 8 DÍGITOS SIMULADO",
                                                    color = SoloPurpleGlow,
                                                    fontSize = 11.sp,
                                                    fontFamily = FontFamily.Monospace,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = "Para completar la vinculación holográfica simulada en este sistema virtual, simplemente pulsa el botón 'VERIFICAR CÓDIGO' de abajo.",
                                                color = SoloWhite,
                                                fontSize = 10.sp,
                                                fontFamily = FontFamily.Monospace,
                                                lineHeight = 13.sp
                                            )
                                        }
                                    }

                                    Text(
                                        text = "Presiona 'VERIFICAR CÓDIGO' abajo para canalizar el enlace de forma automática.",
                                        color = SoloPurpleGlow,
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        textAlign = TextAlign.Center
                                    )
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Button(
                                        onClick = { viewModel.disconnectWhatsApp() },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text(
                                            "CANCELAR",
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = SoloWhite
                                        )
                                    }

                                    Button(
                                        onClick = { viewModel.simulateQRScan() },
                                        colors = ButtonDefaults.buttonColors(containerColor = if (viewModel.connectionMode == "QR") SoloBlue else SoloPurpleGlow),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier
                                            .weight(1.8f)
                                            .graphicsLayer(
                                                scaleX = buttonScale,
                                                scaleY = buttonScale
                                            )
                                            .testTag("simulate_linked_button")
                                    ) {
                                        Text(
                                            text = if (viewModel.connectionMode == "QR") "⚡ AUTO-CONECTAR SIN ESCANEAR" else "⚡ VERIFICAR CÓDIGO SIMULADO",
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 10.sp,
                                            color = SoloWhite,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }

                            "CONNECTED" -> {
                                val isGranted = viewModel.isNotificationAccessGranted(context)

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(RoundedCornerShape(50))
                                            .background(if (isGranted) SoloBlueGlow else RankSOrange)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (isGranted) "CANAL DE SOMBRA ACTIVO (REAL)" else "ANCLAJE COMPLETO (REQUIERE ACCESO)",
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 13.sp,
                                        color = if (isGranted) SoloBlueGlow else RankSOrange
                                    )
                                }

                                Text(
                                    text = "Tu bot '${stats.botName}' está vinculado y listo para responder usando el modelo de IA Gemini 3.5 Flash.",
                                    fontSize = 12.sp,
                                    color = RankEGray,
                                    textAlign = TextAlign.Center
                                )

                                if (!isGranted) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(RankSOrange.copy(alpha = 0.15f))
                                            .border(1.dp, RankSOrange.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                                            .padding(12.dp)
                                    ) {
                                        Column(
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    imageVector = Icons.Default.Warning,
                                                    contentDescription = null,
                                                    tint = RankSOrange,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = "¡PERMISO REQUERIDO PARA WHATSAPP REAL!",
                                                    color = RankSOrange,
                                                    fontSize = 11.sp,
                                                    fontFamily = FontFamily.Monospace,
                                                    fontWeight = FontWeight.Black
                                                )
                                            }
                                            Text(
                                                text = "Para que el chatbot responda de forma REAL a tus chats en tu aplicación física de WhatsApp, debes otorgarle el permiso de 'Acceso a notificaciones' en tu teléfono Android.\n\nPresiona el botón de abajo, busca nuestra aplicación en la lista y actívala.",
                                                color = SoloWhite,
                                                fontSize = 11.sp,
                                                fontFamily = FontFamily.Monospace,
                                                lineHeight = 14.sp,
                                                textAlign = TextAlign.Center
                                            )
                                            Button(
                                                onClick = { viewModel.openNotificationAccessSettings(context) },
                                                colors = ButtonDefaults.buttonColors(containerColor = RankSOrange),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Text(
                                                    "⚡ OTORGAR ACCESO A NOTIFICACIONES",
                                                    fontFamily = FontFamily.Monospace,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 11.sp,
                                                    color = SoloWhite
                                                )
                                            }
                                        }
                                    }
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(SoloBlueGlow.copy(alpha = 0.15f))
                                            .border(1.5.dp, SoloBlueGlow, RoundedCornerShape(10.dp))
                                            .padding(12.dp)
                                    ) {
                                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    imageVector = Icons.Default.CheckCircle,
                                                    contentDescription = null,
                                                    tint = SoloBlueGlow,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = "🟢 CANAL FÍSICO EN SEGUNDO PLANO",
                                                    color = SoloBlueGlow,
                                                    fontSize = 11.sp,
                                                    fontFamily = FontFamily.Monospace,
                                                    fontWeight = FontWeight.Black
                                                )
                                            }
                                            Text(
                                                text = "¡Sincronización Completa! Tu teléfono está configurado como Host de Sombras. El bot responderá de forma automática a los mensajes nuevos de WhatsApp que lleguen a tu móvil en tiempo real.",
                                                color = SoloWhite,
                                                fontSize = 11.sp,
                                                fontFamily = FontFamily.Monospace,
                                                lineHeight = 14.sp
                                            )
                                        }
                                    }
                                }

                                Button(
                                    onClick = { viewModel.disconnectWhatsApp() },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.8f)),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        "PARAR Y RECLUIR BOT",
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = SoloWhite
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Live bot playground test row
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(DarkSlateCard.copy(alpha = 0.8f))
                    .border(1.dp, DarkSlateVariant, RoundedCornerShape(12.dp))
                    .padding(14.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "MANUAL CONTROL (TEST CHATBOT)",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = SoloBlue
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = viewModel.textMessageInput,
                            onValueChange = { viewModel.textMessageInput = it },
                            placeholder = { Text("Mensaje manual al bot...", color = RankEGray, fontSize = 13.sp) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SoloBlue,
                                unfocusedBorderColor = DarkSlateVariant,
                                focusedTextColor = SoloWhite,
                                unfocusedTextColor = SoloWhite
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        )

                        Button(
                            onClick = { viewModel.sendManualTestMessage() },
                            colors = ButtonDefaults.buttonColors(containerColor = SoloBlue),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp),
                            modifier = Modifier.testTag("send_test_message")
                        ) {
                            Icon(imageVector = Icons.Default.Send, contentDescription = null, tint = AbyssBlack)
                        }
                    }
                }
            }
        }

        // CHATBOT ACTIVE CONSOLE LOGS
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "REGISTRO DE TRANSMISIONES DE WHATSAPP",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = RankEGray,
                    fontSize = 11.sp
                )

                if (chatLogs.isNotEmpty()) {
                    Text(
                        text = "LIMPIAR",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = SoloBlue,
                        fontSize = 11.sp,
                        modifier = Modifier.clickable { viewModel.clearChatLogs() }
                    )
                }
            }
        }

        if (chatLogs.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Esperando transmisiones vinculadas...\nSimulación activa cuando Status está CONECTADO",
                        textAlign = TextAlign.Center,
                        color = RankEGray,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        } else {
            items(chatLogs) { log ->
                ChatLogCard(log = log)
            }
        }
    }
}

@Composable
fun ChatLogCard(log: ChatMessage) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(DarkSlateCard.copy(alpha = 0.6f))
            .border(1.dp, DarkSlateVariant, RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = log.sender,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = SoloBlue
                )
                Text(
                    text = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(log.timestamp)),
                    fontSize = 10.sp,
                    color = RankEGray,
                    fontFamily = FontFamily.Monospace
                )
            }

            Text(
                text = log.message,
                fontSize = 13.sp,
                color = SoloWhite
            )

            // Horizontal neon line divider
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(SoloPurple.copy(alpha = 0.3f))
                    .padding(vertical = 4.dp)
            )

            Row(verticalAlignment = Alignment.Top) {
                Text(
                    text = "🤖 BOT: ",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    color = SoloPurpleGlow
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = log.response,
                    fontSize = 12.sp,
                    color = SoloWhite.copy(alpha = 0.9f)
                )
            }
        }
    }
}

// --- TAB 3: SHADOW EXTRACTOR OF MEDIA CORES (DOWNLOADS) ---
@Composable
fun ExtractorTab(
    viewModel: AppViewModel
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(DarkSlateCard)
                    .border(1.dp, SoloBlue, RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(
                        text = "EXTRACTOR DE ENERGÍA DE MEDIOS",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp,
                        color = SoloWhite,
                        letterSpacing = 1.sp
                    )

                    Text(
                        text = "Ingresa el enlace de cualquier red social (TikTok, YouTube, Instagram Reels, Facebook, Twitter) para extraer su sombra y descargarlo en tu inventario.",
                        color = RankEGray,
                        fontSize = 12.sp
                    )

                    // URL address input field
                    OutlinedTextField(
                        value = viewModel.urlInput,
                        onValueChange = { viewModel.urlInput = it },
                        placeholder = { Text("Pega el enlace de video o música aquí...", color = RankEGray, fontSize = 13.sp) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SoloBlue,
                            unfocusedBorderColor = DarkSlateVariant,
                            focusedTextColor = SoloWhite,
                            unfocusedTextColor = SoloWhite
                        ),
                        singleLine = true,
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.Link, contentDescription = null, tint = SoloBlue)
                        },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("url_downloader_input")
                    )

                    // Switches Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "FORMATO: ${if (viewModel.isAudioOnly) "SÓLO AUDIO (MP3)" else "VIDEO COMPLETO (MP4)"}",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = SoloPurpleGlow
                        )

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Audio",
                                fontSize = 12.sp,
                                color = if (viewModel.isAudioOnly) SoloBlue else RankEGray,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Switch(
                                checked = viewModel.isAudioOnly,
                                onCheckedChange = { viewModel.isAudioOnly = it },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = SoloBlue,
                                    checkedTrackColor = DarkSlateVariant,
                                    uncheckedThumbColor = RankEGray,
                                    uncheckedTrackColor = DarkSlateCard
                                )
                            )
                        }
                    }

                    // EPIC ARISE BUTTON
                    Button(
                        onClick = { viewModel.triggerMediaExtraction() },
                        colors = ButtonDefaults.buttonColors(containerColor = SoloPurple),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("arise_download_button")
                    ) {
                        Text(
                            text = "SURGE / ARISE (EXTRAER MEDIO)",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            letterSpacing = 2.sp,
                            color = SoloWhite
                        )
                    }

                    if (viewModel.extractionState == "ERROR") {
                        Text(
                            text = viewModel.errorMessage,
                            color = Color.Red,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }

        // Demo URLs helpers to help user try immediately
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "CANALES DE PRUEBA (ENLACES RÁPIDOS)",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = RankEGray
                )

                DemoLinkCard(
                    title = "Demo Direct Link Mp3 (Epic Anime Track)",
                    url = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
                    onSelect = { viewModel.urlInput = it; viewModel.isAudioOnly = true }
                )

                DemoLinkCard(
                    title = "Demo Direct Link Mp4 (Cinematic Clip)",
                    url = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
                    onSelect = { viewModel.urlInput = it; viewModel.isAudioOnly = false }
                )

                DemoLinkCard(
                    title = "Simulado YouTube Music Link",
                    url = "https://youtube.com/watch?v=igris_monarch_shadow",
                    onSelect = { viewModel.urlInput = it; viewModel.isAudioOnly = true }
                )

                DemoLinkCard(
                    title = "Simulado TikTok Reel Clip",
                    url = "https://tiktok.com/@solo_leveling_system/video/995212",
                    onSelect = { viewModel.urlInput = it; viewModel.isAudioOnly = false }
                )
            }
        }
    }
}

@Composable
fun DemoLinkCard(
    title: String,
    url: String,
    onSelect: (String) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(DarkSlateCard.copy(alpha = 0.5f))
            .border(1.dp, DarkSlateVariant, RoundedCornerShape(8.dp))
            .clickable { onSelect(url) }
            .padding(10.dp)
    ) {
        Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = SoloBlue
                )
                Text(
                    text = url,
                    fontSize = 11.sp,
                    color = RankEGray,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = RankEGray,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

// --- TAB 4: SHADOW INVENTORY WITH INTERNAL PLAYBACK CONTROLS ---
@Composable
fun InventoryTab(
    mediaList: List<DownloadedMedia>,
    playingMedia: DownloadedMedia?,
    isAudioPlaying: Boolean,
    onPlayMedia: (DownloadedMedia) -> Unit,
    onDeleteMedia: (DownloadedMedia) -> Unit,
    onStopAudio: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = "INVENTARIO DE SOMBRAS RECLUTADAS",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            color = SoloWhite,
            fontSize = 14.sp,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        if (mediaList.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(
                        imageVector = Icons.Default.HourglassEmpty,
                        contentDescription = null,
                        tint = RankEGray,
                        modifier = Modifier.size(48.dp)
                    )
                    Text(
                        text = "El inventario de sombras está vacío.\nExtrae núcleos de medios para poblar tus filas.",
                        textAlign = TextAlign.Center,
                        color = RankEGray,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(mediaList) { media ->
                    MediaInventoryCard(
                        media = media,
                        isActive = playingMedia == media,
                        isAudioPlaying = isAudioPlaying,
                        onPlay = { onPlayMedia(media) },
                        onDelete = { onDeleteMedia(media) }
                    )
                }
            }
        }

        // Inline Video Player Panel
        if (playingMedia != null && playingMedia.mimeType.contains("video")) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(DarkSlateCard)
                    .border(1.dp, SoloBlueGlow, RoundedCornerShape(12.dp))
                    .padding(8.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "REPRODUCIENDO SOMBRA: ${playingMedia.title}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = SoloBlueGlow,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { onStopAudio() },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = null, tint = Color.Red)
                        }
                    }

                    // Native VideoView embedded in Compose
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.Black),
                        contentAlignment = Alignment.Center
                    ) {
                        AndroidView(
                            factory = { ctx ->
                                VideoView(ctx).apply {
                                    setVideoURI(Uri.fromFile(File(playingMedia.filePath)))
                                    setOnPreparedListener { mp ->
                                        mp.isLooping = true
                                        start()
                                    }
                                }
                            },
                            update = { view ->
                                view.setVideoURI(Uri.fromFile(File(playingMedia.filePath)))
                                view.start()
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }
        }

        // Inline Audio Player Banner
        if (playingMedia != null && playingMedia.mimeType.contains("audio")) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(DarkSlateCard)
                    .border(1.dp, SoloPurpleGlow, RoundedCornerShape(12.dp))
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "ESCUCHANDO FRECUENCIA",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = SoloPurpleGlow,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = playingMedia.title,
                            color = SoloWhite,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { onPlayMedia(playingMedia) }) {
                            Icon(
                                imageVector = if (isAudioPlaying) Icons.Default.PauseCircle else Icons.Default.PlayCircle,
                                contentDescription = null,
                                tint = SoloBlue,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                        IconButton(onClick = { onStopAudio() }) {
                            Icon(imageVector = Icons.Default.Stop, contentDescription = null, tint = RankEGray)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MediaInventoryCard(
    media: DownloadedMedia,
    isActive: Boolean,
    isAudioPlaying: Boolean,
    onPlay: () -> Unit,
    onDelete: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(if (isActive) DarkSlateVariant else DarkSlateCard)
            .border(
                1.dp,
                if (isActive) SoloBlue else DarkSlateVariant,
                RoundedCornerShape(10.dp)
            )
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left icon representing audio vs video
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(DarkSlateVariant),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (media.mimeType.contains("audio")) Icons.Default.MusicNote else Icons.Default.Movie,
                    contentDescription = null,
                    tint = if (isActive) SoloBlueGlow else SoloPurpleGlow,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Body text
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = media.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = SoloWhite,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = media.sourcePlatform.uppercase(),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = SoloBlue
                    )
                    Text(
                        text = media.duration,
                        fontSize = 11.sp,
                        color = RankEGray
                    )
                    Text(
                        text = "%.1f MB".format(media.fileSize / 1000000.0),
                        fontSize = 11.sp,
                        color = RankEGray
                    )
                }
            }

            // Right actions (play & delete)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onPlay) {
                    val icon = if (media.mimeType.contains("audio")) {
                        if (isActive && isAudioPlaying) Icons.Default.Pause else Icons.Default.PlayArrow
                    } else {
                        Icons.Default.Visibility
                    }
                    Icon(imageVector = icon, contentDescription = null, tint = SoloBlue)
                }

                IconButton(onClick = onDelete) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = null, tint = Color.Red.copy(alpha = 0.8f))
                }
            }
        }
    }
}

// --- ALARM EXTRACTION PROCESS OVERLAY (SOLO LEVELING STYLE "ARISE") ---
@Composable
fun ExtractionOverlay(
    state: String,
    progress: Int,
    metadata: MediaMetadata?
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.92f)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.padding(24.dp)
        ) {
            // Warning alerts for extraction animation
            if (state == "AR ARISING") {
                Text(
                    text = "DESPIERTA / ARISING / SURGE",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    fontSize = 24.sp,
                    color = SoloBlueGlow,
                    letterSpacing = 3.sp,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(10.dp))

                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = SoloPurpleGlow,
                    modifier = Modifier.size(80.dp)
                )

                Text(
                    text = "EXTRAYENDO LA SOMBRA DEL CONTENIDO...",
                    fontFamily = FontFamily.Monospace,
                    color = SoloWhite,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = metadata?.title ?: "Analizando fluctuaciones de Mana...",
                    color = RankEGray,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center
                )
            } else if (state == "EXTRACTING") {
                CircularProgressIndicator(color = SoloBlue, modifier = Modifier.size(50.dp))
                Text(
                    text = "CANALIZANDO GRIETA RED SOCIAL...",
                    fontFamily = FontFamily.Monospace,
                    color = SoloBlue,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            } else {
                // Download progress bar
                Text(
                    text = "ABSORBIENDO FLUJO BINARIO",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = SoloBlue
                )

                Text(
                    text = "$progress%",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Black,
                    color = SoloWhite
                )

                // custom linear loader
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.8f)
                        .height(12.dp)
                        .clip(RoundedCornerShape(50))
                        .background(DarkSlateVariant)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(progress / 100f)
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(SoloPurple, SoloBlue)
                                )
                            )
                    )
                }

                Text(
                    text = metadata?.title ?: "Clonando sombra en almacenamiento...",
                    fontSize = 11.sp,
                    color = RankEGray,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

// --- STUNNING LEVEL UP SUCCESS DIALOG WINDOW (SOLO LEVELING TRADEMARK) ---
@Composable
fun LevelUpOverlay(
    oldLevel: Int,
    newLevel: Int,
    rank: String,
    onDismiss: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.9f))
            .clickable { onDismiss() },
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .width(320.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(DarkSlateCard)
                .border(2.dp, GoldAccent, RoundedCornerShape(16.dp))
                .padding(24.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Shimmering Golden Winged Emblem
                Icon(
                    imageVector = Icons.Default.OfflineBolt,
                    contentDescription = null,
                    tint = GoldAccent,
                    modifier = Modifier.size(64.dp)
                )

                Text(
                    text = "LEVEL UP! (¡SUBIDA DE NIVEL!)",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    fontSize = 20.sp,
                    color = GoldAccent,
                    letterSpacing = 2.sp
                )

                Text(
                    text = "El sistema ha registrado tus hazañas vinculando el bot de WhatsApp y extrayendo sombras de internet.",
                    fontSize = 12.sp,
                    color = RankEGray,
                    textAlign = TextAlign.Center
                )

                // Level comparison box
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "NIVEL $oldLevel",
                        color = RankEGray,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = null,
                        tint = SoloBlue
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "NIVEL $newLevel",
                        color = SoloBlue,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 22.sp
                    )
                }

                // New Rank text info
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(RankSOrange.copy(alpha = 0.2f))
                        .border(1.dp, RankSOrange, RoundedCornerShape(8.dp))
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = rank,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        color = SoloWhite
                    )
                }

                Text(
                    text = "[Toca en cualquier parte para continuar]",
                    fontSize = 10.sp,
                    color = RankEGray,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
