package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Solo Leveling Palette
val SoloBlue = Color(0xFF00E5FF)       // System glowing cyan-blue
val SoloBlueGlow = Color(0xFF00F5FF)   // Neon active electric blue
val SoloPurple = Color(0xFF8E24AA)     // Monarch dark shadow violet
val SoloPurpleGlow = Color(0xFFD500F9) // Glowing shadow purple
val SoloWhite = Color(0xFFF1F5F9)      // Platinum highlight

val AbyssBlack = Color(0xFF06080E)     // Depths of the Double Dungeon
val DarkSlateCard = Color(0xFF111625)  // Hunter interface backing
val DarkSlateVariant = Color(0xFF1B2237) // System window frames
val GoldAccent = Color(0xFFFFD700)     // Golden quest completions
val RankEGray = Color(0xFF94A3B8)      // Starter E-rank gray
val RankSOrange = Color(0xFFF97316)    // S-rank high-priority warning glow
